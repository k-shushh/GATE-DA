# GATE Lab

A static, interactive GATE DA study notebook. Open `index.html` or serve this folder. No frontend build or package installation is required.

## Included tracks

| Track | Lessons | Topic questions | Flashcards |
|---|---:|---:|---:|
| Python | 41 | 120 | 60 |
| Data structures & algorithms | 39 | 130 | 65 |
| Database management & warehousing | 36 | 120 | 60 |
| Linear Algebra | 36 | 120 | 60 |
| Calculus & Optimization | 21 | 70 | 35 |

Mathematics adds 19 interactive visual labs, 57 lesson checkpoints, 190 original topic questions, and 39 official 2024–2026 DA question references (24 LA and 15 calculus, including clearly labeled applications). Each math track has a 20-question mixed revision set: 10 original conceptual questions selected from the topic bank and 10 core PYQs. PYQ wording and options remain in the linked official papers; answer entry and official-key feedback work in the site.

Scope is mapped to the official [GATE DA 2027 syllabus](https://gate2027.iitm.ac.in/static/doc/GATE2027_Syllabus/DA_GATE2027_Syllabus.pdf). Sections 2–5 are covered. Probability & Statistics, Machine Learning and AI are separate future tracks. QR, Cholesky, PCA, integration and multivariable calculus are identified as supporting depth, not additional named Section 2–3 requirements.

## Study locally

Open `index.html` directly for lessons, visualizations, quizzes and flashcards. A local HTTP server is recommended for predictable browser storage and runtime loading:

```sh
python -m http.server 8767 --bind 127.0.0.1
```

Then open `http://127.0.0.1:8767/`. Stop the server with Ctrl+C.

Python execution loads Pyodide and requested packages from a CDN; the SQL workbench loads sql.js. Those runtimes and external official papers require internet. Downloaded `.py` files can run locally; the math examples need NumPy. The rest of the study interface works offline.

Completion, answers, edited code, notes, bookmarks and flashcard schedules stay in browser local storage. The existing storage key and older lesson IDs are preserved. Export a progress JSON from Downloads before changing origins, browsers or devices, then import it at the destination. Local files, localhost and GitHub Pages do not share browser storage automatically.

## Update the existing GitHub Pages site

This checkout uses a **flat repository root**, with `index.html` beside the `.js`, `.css`, PDF and ZIP files. It does not use a `dist/` folder.

Commit the updated root files to your existing `GATE-DA` repository and push to its publishing branch. If configuring branch-based Pages, choose Settings → Pages → Deploy from a branch, the publishing branch, and `/(root)`. Keep `.nojekyll`. See the [official GitHub publishing-source instructions](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

No deployment or remote push is performed by editing this local folder. Publishing this repository at the same GitHub Pages location retains the existing public URL.

## Source organization

- `math-course.js`, `math-advanced.js`: 12 Linear Algebra modules.
- `calc-course.js`: 7 calculus modules, including the supporting bridge.
- `math-practice.js`: original questions and recall cards.
- `math-pyqs.js`: verified references, types, answers and official links.
- `math-labs.js`: pure numerical models plus SVG controls and explanations.
- `math-reference.js`: formula tables with assumptions.
- `math-ui.js`, `math.css`: math track pages, formula desk and exam rooms.
- `app.js`: shared routing, progress, question grading, downloads and Python runner.
- `*-notes.html`: full printable companions; `*-revision.pdf` and `*-formulas.pdf`: recall editions.

## Validate and regenerate mathematics downloads

Requires Node.js and Python with `numpy`, `reportlab`, `matplotlib`, `fonttools` and `pillow`. These are authoring dependencies only; visitors do not install them.

```sh
node tools/export_course.mjs
python tools/build_math_outputs.py
node tools/export_course.mjs
node tools/test_math.mjs
python tools/build_math_downloads.py
python tools/package_site.py
```

The output builder executes every math example and solution. The model test checks numerical invariants, rank-deficient cases, pivot permutations, question identities and content structure. PDFs use embedded DejaVu fonts. `qa/` contains generated verification data and is excluded from exports and Git.

`gate-lab-source.zip` contains the site plus maintenance tools. `python-studio-offline.zip` is the static study edition (filename retained for compatibility with older download links). These bundles exclude Git history, QA files and recursive copies of themselves. Their own full-site download buttons show an offline-edition message when opened from disk.
