from pathlib import Path
import hashlib,json,re,zipfile
from pypdf import PdfReader
root=Path(__file__).resolve().parents[1]
missing=[]
for p in list(root.glob('*.html'))+list(root.glob('*.js')):
    text=p.read_text(encoding='utf-8')
    for ref in re.findall(r'(?:href|src)=[\"\x27]([^\"\x27]+)[\"\x27]',text):
        if ref.startswith(('http:','https:','#','data:')) or any(c in ref for c in ('$',"'",'<','+')):continue
        path=ref.split('#')[0].split('?')[0]
        if path and not (root/path).exists():missing.append((p.name,ref))
assert not missing,missing
baseline=root.parent/'tmp/gate-da-copy-verification.json'
changed=[]
if baseline.exists():
    for item in json.loads(baseline.read_text(encoding='utf-8-sig')):
        digest=hashlib.sha256((root/item['File']).read_bytes()).hexdigest().upper()
        if digest!=item['SHA256']:changed.append(item['File'])
    assert set(changed)<=set(['app.js','index.html','github-pages.html','START-HERE.txt']),changed
pdfs={}
for name in ['la-revision','la-formulas','calc-revision','calc-formulas']:
    reader=PdfReader(root/(name+'.pdf'))
    assert all(len(p.extract_text())>100 for p in reader.pages)
    pdfs[name]=len(reader.pages)
archives={}
for name in ['gate-lab-source.zip','python-studio-offline.zip','la-examples.zip','calc-examples.zip']:
    with zipfile.ZipFile(root/name) as z:
        assert z.testzip() is None
        assert not any(n.startswith(('.git/','qa/')) for n in z.namelist())
        archives[name]=len(z.namelist())
        if name in ['gate-lab-source.zip','python-studio-offline.zip']:
            assert b'data-bundled="true"' in z.read('index.html')
            for ref in re.findall(r'<script src="([^"]+)"',z.read('index.html').decode()):assert ref in z.namelist(),ref
report={'missing_local_links':missing,'changed_baseline_files':changed,'pdf_pages':pdfs,'archive_entries':archives}
(root/'qa/artifact-verification.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
