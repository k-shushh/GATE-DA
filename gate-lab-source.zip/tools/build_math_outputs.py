from pathlib import Path
import contextlib,io,json
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'qa/course.json').read_text(encoding='utf-8'))
outputs={};solutions={}
for m in data['course']:
    if m.get('track') not in ('la','calc'):continue
    for l in m['lessons']:
        for field,target in [('code',outputs),('solution',solutions)]:
            buf=io.StringIO()
            with contextlib.redirect_stdout(buf):exec(compile(l[field],l['id']+'-'+field,'exec'),{'__name__':'__main__'})
            target[l['id']]=buf.getvalue().rstrip()
(root/'math-outputs.js').write_text('const MATH_OUTPUTS='+json.dumps(outputs,ensure_ascii=False,indent=2)+';\nfor(const m of COURSE)for(const l of m.lessons)if(MATH_OUTPUTS[l.id]!==undefined)l.output=MATH_OUTPUTS[l.id];\n',encoding='utf-8')
(root/'qa/math-solutions.json').write_text(json.dumps(solutions,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'Executed {len(outputs)} examples and {len(solutions)} solutions successfully.')
