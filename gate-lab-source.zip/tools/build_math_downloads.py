"""Build portable study material from the same tested lesson data as the site."""
from pathlib import Path
import csv,html,json,zipfile,unicodedata
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import matplotlib
from fontTools.ttLib import TTFont as FontInfo
root=Path(__file__).resolve().parents[1]
data=json.loads((root/'qa/course.json').read_text(encoding='utf-8'))
fonts=Path(matplotlib.get_data_path())/'fonts/ttf'
for name,file in [('Study','DejaVuSans.ttf'),('StudyBold','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fonts/file)))
pdfmetrics.registerFontFamily('Study',normal='Study',bold='StudyBold',italic='Study',boldItalic='StudyBold')
cmap=FontInfo(fonts/'DejaVuSans.ttf').getBestCmap()
missing=set()
def clean(s):
    s=s.replace('–','-').replace('—','-').replace('‑','-')
    out=''
    for ch in s:
        if ord(ch) in cmap or ch in '\n\t':out+=ch
        else:
            rep=unicodedata.normalize('NFKC',ch)
            if rep!=ch and all(ord(c) in cmap for c in rep):out+=rep
            else:missing.add(ch);out+='['+unicodedata.name(ch,'symbol').lower()+']'
    return html.escape(out)
styles={
 'title':ParagraphStyle('title',fontName='StudyBold',fontSize=27,leading=34,textColor=HexColor('#263d6c'),spaceAfter=15),
 'h1':ParagraphStyle('h1',fontName='StudyBold',fontSize=17,leading=22,textColor=HexColor('#263d6c'),spaceAfter=12),
 'h2':ParagraphStyle('h2',fontName='StudyBold',fontSize=11,leading=15,textColor=HexColor('#263d6c'),spaceBefore=11,spaceAfter=6,keepWithNext=True),
 'body':ParagraphStyle('body',fontName='Study',fontSize=9,leading=13.5,spaceAfter=7),
 'formula':ParagraphStyle('formula',fontName='Study',fontSize=10,leading=16,backColor=HexColor('#eef1fb'),borderPadding=9,spaceBefore=7,spaceAfter=13),
 'small':ParagraphStyle('small',fontName='Study',fontSize=8,leading=12,spaceAfter=6,textColor=HexColor('#526071'))
}
def P(s,kind='body'):return Paragraph(clean(s),styles[kind])
def footer(canvas,doc):
    canvas.setStrokeColor(HexColor('#d2d9e7'));canvas.line(42,38,A4[0]-42,38)
    canvas.setFont('Study',8);canvas.setFillColor(HexColor('#526071'));canvas.drawString(42,25,'GATE LAB  /  DA 2027  /  Study • reason • recall');canvas.drawRightString(A4[0]-42,25,str(doc.page))
def build(name,story):
    SimpleDocTemplate(str(root/name),pagesize=A4,rightMargin=43,leftMargin=43,topMargin=42,bottomMargin=52,title=name.replace('-',' ').removesuffix('.pdf'),author='GATE Lab',pageCompression=1).build(story,onFirstPage=footer,onLaterPages=footer)
syllabus='https://gate2027.iitm.ac.in/static/doc/GATE2027_Syllabus/DA_GATE2027_Syllabus.pdf'
for track,title in [('la','Linear Algebra'),('calc','Calculus & Optimization')]:
    mods=[m for m in data['course'] if m.get('track')==track]
    intro=[P('GATE LAB / MATHEMATICS','small'),P(title,'title'),P('Revision companion','h1'),P('Use this after the guided lessons: cover each worked answer, recall the rule, then solve the example on paper. Every module includes its key formulas, conditions and common traps. Full explanations and runnable examples are in the companion HTML notes.'),P('Scope: '+('Every named Section 2 topic, plus explicitly identified applications such as QR, Cholesky, pseudoinverses and PCA.' if track=='la' else 'Every named Section 3 topic. Integration, gradients and Hessians form an additional supporting bridge.')),Paragraph('<link href="'+syllabus+'" color="#4255a0">Official GATE DA 2027 syllabus ↗</link>',styles['small']),Spacer(1,15)]
    intro += [P(str(i+1).zfill(2)+'  '+m['title'],'body') for i,m in enumerate(mods)]
    story=intro
    for i,m in enumerate(mods):
        story += [PageBreak(),P(f'{i+1:02d} / '+m['title'],'h1'),P(m['subtitle'],'small')]
        for l in m['lessons']:
            story += [P(l['title'].split(' · ')[1],'h2'),P(l['concepts'][0]),P(l['formula'],'formula'),P('Work it through: '+' '.join(l['mathSteps'])),P('Watch the trap: '+l['trap'],'small'),P('Recall task: '+l['task'],'small'),P('Worked answer: '+l['mathAnswer'],'small')]
    story += [PageBreak(),P('A final retrieval pass','h1')]
    for i,q in enumerate(data['final'][track]):story += [P(f'{i+1}. '+q['prompt'],'h2'),P(' / '.join(q['options']))]
    story += [PageBreak(),P('Answers & reasoning','h1')]
    for i,q in enumerate(data['final'][track]):story += [P(f'{i+1}. '+q['options'][q['answer']],'h2'),P(q['explain'])]
    build(track+'-revision.pdf',story)
    formulas=[P('GATE LAB / QUICK RECALL','small'),P(title,'title'),P('Formula sheet + conditions','h1'),P('A formula is useful only with its assumptions. This sheet pairs each relationship with a reminder of a limitation or common mistake. Read the linked lesson notes for derivations and examples. Symbols: Aᵀ is transpose, A⁻¹ inverse, A⁺ pseudoinverse, ||·||₂ Euclidean/operator 2-norm, I identity, λ eigenvalue, σ singular value. Derivatives use radians and natural logarithms unless stated otherwise.'),Spacer(1,10)]
    for ref in data['reference'][track]:
        formulas += [KeepTogether([P(ref['title'],'h2'),Paragraph(clean(ref['formula']).replace('\n','<br/>'),styles['formula']),P(ref['note'],'small')])]
    formulas += [PageBreak(),P('Lesson-by-lesson recall','h1')]
    for m in mods:
        block=[P(m['title'],'h2')]
        for l in m['lessons']:block += [P(l['formula'],'formula'),P(l['trap'],'small')]
        formulas += [KeepTogether(block)]
    build(track+'-formulas.pdf',formulas)
    h=['<!doctype html><html lang="en"><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+' · Complete notes</title><style>body{font:16px/1.8 system-ui,sans-serif;max-width:900px;margin:40px auto;padding:0 24px;color:#20322f;background:#fffefa}h1,h2,h3{line-height:1.3;color:#2b416d}h1{font-size:42px}h2{margin-top:55px;border-top:1px solid #ccd3df;padding-top:28px}h3{margin-top:36px}pre{white-space:pre-wrap;overflow-wrap:anywhere;padding:20px;background:#eef2f7;border-radius:8px;font:13px/1.7 monospace}.formula{font:21px/1.8 Georgia,serif;background:#eef1fb;padding:20px;border-left:3px solid #7783c7}aside{background:#f2f6e9;padding:18px;margin:20px 0}a{color:#4255a0}li{margin:8px 0}button{padding:10px 16px}@media print{button,nav{display:none}body{font-size:10pt}h2{break-before:page}pre,aside{break-inside:avoid}}</style><h1>'+title+'</h1><p>Complete lessons, hand-worked examples, Python checks, practice tasks and answers.</p><button onclick="print()">Print / Save PDF</button><nav><a href="index.html#'+track+'">← Interactive track</a></nav>']
    h+=['<h2>Essential formula reference</h2>']
    for ref in data['reference'][track]:h+=['<h3>'+html.escape(ref['title'])+'</h3><div class="formula" style="white-space:pre-line">'+html.escape(ref['formula'])+'</div><p>'+html.escape(ref['note'])+'</p>']
    for m in mods:
        h+=['<h2>'+html.escape(m['title'])+'</h2><p>'+html.escape(m['subtitle'])+'</p>']
        for l in m['lessons']:
            h+=['<h3>'+html.escape(l['title'])+'</h3>']+['<p>'+html.escape(p)+'</p>' for p in l['concepts']]
            h+=['<div class="formula">'+html.escape(l['formula'])+'</div><h4>Work it through</h4><ol>'+''.join('<li>'+html.escape(x)+'</li>' for x in l['mathSteps'])+'</ol><aside><b>Application:</b> '+html.escape(l['application'])+'<br><b>Watch the trap:</b> '+html.escape(l['trap'])+'</aside><pre>'+html.escape(l['code'])+'</pre><h4>Expected output</h4><pre>'+html.escape(l['output'])+'</pre><h4>Your turn</h4><p>'+html.escape(l['task'])+'</p><p><b>Worked answer:</b> '+html.escape(l['mathAnswer'])+'</p><pre>'+html.escape(l['solution'])+'</pre>']
        h+=['<h3>Topic practice: 10 questions</h3>']
        for i,q in enumerate(m['questions']):h+=['<p><b>'+str(i+1)+'. '+html.escape(q['prompt'])+'</b></p><ol type="A">'+''.join('<li>'+html.escape(o)+'</li>' for o in q['options'])+'</ol><details><summary>Answer & reasoning</summary><p>'+html.escape(q['options'][q['answer']]+'. '+q['explain'])+'</p></details>']
    h+=['<h2>Official PYQ references</h2><p>Open the paper for exact wording and options. Keys are official; short explanations in the interactive exam room are study cues.</p>']
    for p in data['pyqs']:
        if p['track']==track:h+=['<p><a href="'+p['paperUrl']+'#page='+str(p['page'])+'">DA '+str(p['year'])+' Q'+str(p['number'])+'</a> · <a href="'+p['keyUrl']+'">Official key</a>'+(' · application/enrichment' if p['enrichment'] else '')+'</p>']
    h+=['<p><a href="'+syllabus+'">Official syllabus</a> · Original teaching material, GATE Lab.</p></html>']
    (root/(track+'-notes.html')).write_text('\n'.join(h),encoding='utf-8')
    with (root/(track+'-flashcards.csv')).open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['Topic','Front','Back'])
        for m in mods:
            for c in m['cards']:writer.writerow([m['title'],c['front'],c['back']])
    with zipfile.ZipFile(root/(track+'-examples.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('README.txt','Python 3.10+ recommended. Install NumPy with: python -m pip install numpy\nRun an individual .py file. These examples use standard Python and NumPy.\n')
        for m in mods:
            for l in m['lessons']:
                for field,suffix in [('code','example'),('solution','solution')]:z.writestr(l['id']+'-'+suffix+'.py','# '+l['title']+'\n'+l[field]+'\n')
print('Created 4 PDFs, 2 full HTML companions, 2 example ZIPs and 2 flashcard CSVs. Unsupported glyph substitutions:',ascii(sorted(missing)))
