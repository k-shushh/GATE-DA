import fs from 'node:fs';import vm from 'node:vm';import assert from 'node:assert/strict';
const ctx=vm.createContext({console});ctx.window=ctx;
vm.runInContext(fs.readFileSync('math-labs.js','utf8'),ctx);const M=ctx.MATH_MODELS;
let checks=0;const near=(a,b,tol=1e-8)=>{assert.ok(Math.abs(a-b)<tol,`${a} != ${b}`);checks++;};
let seed=173;const rng=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/2**32*6-3;};
for(let k=0;k<150;k++){
 const A=[[rng(),rng()],[rng(),rng()]],x=[rng(),rng()],b=M.mv(A,x),e=M.elimination(A.map((r,i)=>[...r,b[i]]),2);
 assert.equal(e.rank,2);near(e.A[0][2],x[0]);near(e.A[1][2],x[1]);
 const lu=M.lu(A),pa=M.mul(lu.P,A),product=M.mul(lu.L,lu.U);for(let i=0;i<2;i++)for(let j=0;j<2;j++)near(pa[i][j],product[i][j]);
 const sv=M.svd(A);near(sv.s[0]**2+sv.s[1]**2,A.flat().reduce((s,v)=>s+v*v,0));near(sv.s[0]*sv.s[1],Math.abs(M.det(A)),1e-6);
 const sym=[[A[0][0],A[0][1]],[A[0][1],A[1][1]]],eig=M.eigenSym(sym[0][0],sym[0][1],sym[1][1]);eig.vectors.forEach((v,i)=>M.mv(sym,v).forEach((z,j)=>near(z,eig.values[i]*v[j])));
 const p=M.projection(x,b),r=b.map((z,i)=>z-p[i]);near(M.dot(x,r),0);near(M.dot(b,b),M.dot(p,p)+M.dot(r,r));
}
assert.equal(M.elimination([[1,2,3],[2,4,7]],2).inconsistent,true);
assert.equal(M.elimination([[1,2,3],[2,4,6]],2).nullity,1);
assert.equal(M.elimination([[0,0,0],[0,0,0]],2).rank,0);
assert.equal(M.projection([0,0],[1,2]),null);
assert.equal(M.lu([[1,2],[2,4]]).singular,true);
const A3=[[0,2,1],[3,1,4],[1,5,2]],lu3=M.lu(A3);M.mul(lu3.P,A3).forEach((r,i)=>r.forEach((v,j)=>near(v,M.mul(lu3.L,lu3.U)[i][j])));
const fit=M.fit([0,1,2],[1,2,2]);near(fit.slope,.5);near(fit.intercept,7/6);near(fit.sse,1/6);
near(M.taylor(.2,4,'cos'),1-.2**2/2+.2**4/24);near(M.taylor(.2,3,'exp'),1+.2+.2**2/2+.2**3/6);
near(M.descent(0,.25,3).at(-1),2.625);near(M.descent(0,1,2).at(-1),0);
const data=JSON.parse(fs.readFileSync('qa/course.json','utf8')),math=data.course.filter(m=>['la','calc'].includes(m.track)),all=data.course.flatMap(m=>m.lessons),ids=new Set();
for(const m of math){assert.equal(m.questions.length,10);assert.equal(m.cards.length,5);assert.equal(m.lessons.length,3);for(const l of m.lessons){assert.equal(l.concepts.length,4);assert.equal(l.mathSteps.length,4);assert.ok(l.formula&&l.mathAnswer&&l.application&&l.output);assert.ok(data.labs.some(v=>v[0]===l.visual));if(l.recap)assert.ok(all.some(x=>x.id===l.recap));}for(const q of [...m.questions,...m.lessons.map(l=>l.check),...m.cards]){assert.ok(!ids.has(q.id),q.id);ids.add(q.id);if(q.options){assert.equal(q.options.length,4);assert.ok(Number.isInteger(q.answer)&&q.answer>=0&&q.answer<4);assert.equal(new Set(q.options).size,4);}}}
for(const p of data.pyqs){assert.ok(p.paperUrl.startsWith('https://gate2026.iitg.ac.in/'));assert.ok(p.keyUrl&&p.page>0);assert.ok(math.some(m=>m.id===p.track+'-'+p.module),p.id);}
for(const name of fs.readdirSync('.').filter(s=>s.endsWith('.js')))new vm.Script(fs.readFileSync(name,'utf8'),{filename:name});
const legacy=data.course.filter(m=>!['la','calc'].includes(m.track));assert.equal(legacy.length,37);assert.equal(legacy.flatMap(m=>m.lessons).length,116);
console.log(`${checks} numerical assertions passed; 57 lessons, 190 topic questions, 95 cards and 39 PYQ references validated. All JavaScript parses.`);
