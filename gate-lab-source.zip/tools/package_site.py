from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1]
bundles={'gate-lab-source.zip','python-studio-offline.zip'}
site=[p for p in root.iterdir() if p.is_file() and p.name not in bundles and (p.suffix in ('.html','.css','.js','.pdf','.zip','.csv','.txt') or p.name=='.nojekyll')]
for name in sorted(bundles):
    files=site[:]
    if name=='gate-lab-source.zip':files += [root/'README.md',root/'.gitattributes',root/'.gitignore']+list((root/'tools').glob('*.py'))+list((root/'tools').glob('*.mjs'))
    with zipfile.ZipFile(root/name,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:
            if p.name=='index.html':z.writestr(p.name,p.read_text(encoding='utf-8').replace('<body>','<body data-bundled="true">'))
            elif p.name=='github-pages.html':z.writestr(p.name,p.read_text(encoding='utf-8').replace('<a href="gate-lab-source.zip" download>the source ZIP</a>','the source ZIP (already extracted here)'))
            else:z.write(p,p.relative_to(root).as_posix())
    with zipfile.ZipFile(root/name) as z:assert z.testzip() is None
    print(name,len(files),'files',round((root/name).stat().st_size/1024),'KiB')
