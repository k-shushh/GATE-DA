from pathlib import Path
from PIL import Image,ImageOps,ImageDraw
root=Path(__file__).resolve().parents[1]/'qa/pdf-render'
files=sorted(root.glob('*.png'))
for n in range(0,len(files),8):
    canvas=Image.new('RGB',(1200,900),'#d8dce3');d=ImageDraw.Draw(canvas)
    for k,p in enumerate(files[n:n+8]):
        im=Image.open(p).convert('RGB');im.thumbnail((280,410))
        x=(k%4)*300+(300-im.width)//2;y=(k//4)*450+25
        canvas.paste(im,(x,y));d.text(((k%4)*300+12,(k//4)*450+6),p.stem,fill='black')
    canvas.save(root/f'contact-{n//8+1}.jpg')
print(len(files),'pages rendered into',(len(files)+7)//8,'contact sheets')
