SELECT DISTINCT city FROM student WHERE score>=70 ORDER BY city;
