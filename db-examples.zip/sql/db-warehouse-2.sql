SELECT city,SUM(revenue) AS revenue FROM sales GROUP BY city UNION ALL SELECT 'ALL',SUM(revenue) FROM sales;
