SELECT s.name, e.cid FROM student s LEFT JOIN enrol e ON s.id=e.sid AND e.mark>=90 ORDER BY s.id,e.cid;
