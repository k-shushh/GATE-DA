SELECT s.name FROM student s WHERE EXISTS (SELECT 1 FROM enrol e WHERE e.sid=s.id AND e.mark>=90) ORDER BY s.id;
