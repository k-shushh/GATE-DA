SELECT name, score IS NULL AS missing FROM student ORDER BY id;
