WITH totals AS (SELECT sid,SUM(mark) AS total FROM enrol GROUP BY sid) SELECT s.name,t.total FROM totals t JOIN student s ON s.id=t.sid ORDER BY t.total DESC,s.id;
