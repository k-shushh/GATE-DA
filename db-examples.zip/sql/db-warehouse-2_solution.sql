SELECT 4*3*2 AS cuboids;
