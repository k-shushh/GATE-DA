SELECT s.name, COUNT(e.cid) AS n FROM student s LEFT JOIN enrol e ON s.id=e.sid GROUP BY s.id,s.name ORDER BY s.id;
