SELECT id FROM course EXCEPT SELECT cid FROM enrol;
