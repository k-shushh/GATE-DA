SELECT c.title,COUNT(e.sid) FROM course c LEFT JOIN enrol e ON c.id=e.cid GROUP BY c.id,c.title ORDER BY c.id;
