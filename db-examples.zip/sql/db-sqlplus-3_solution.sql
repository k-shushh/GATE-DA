SELECT city,month,product,revenue,SUM(revenue) OVER(PARTITION BY city) AS city_total,ROUND(1.0*revenue/SUM(revenue) OVER(PARTITION BY city),2) AS share FROM sales ORDER BY city,month,product;
