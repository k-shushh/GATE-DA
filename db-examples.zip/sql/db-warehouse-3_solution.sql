SELECT 1.0*(10*2+30*8)/(2+8) AS weighted_mean;
