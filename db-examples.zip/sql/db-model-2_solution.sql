SELECT c.title FROM course c LEFT JOIN enrol e ON e.cid=c.id WHERE e.sid IS NULL;
