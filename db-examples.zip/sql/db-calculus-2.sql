SELECT s.name FROM student s WHERE NOT EXISTS (SELECT 1 FROM enrol e WHERE e.sid=s.id AND e.mark<70) ORDER BY s.id;
