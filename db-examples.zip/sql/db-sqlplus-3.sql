SELECT name,score,DENSE_RANK() OVER(ORDER BY score DESC) AS place FROM student WHERE score IS NOT NULL ORDER BY score DESC,id;
