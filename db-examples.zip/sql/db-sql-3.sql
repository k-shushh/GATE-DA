SELECT s.name FROM student s WHERE s.id NOT IN (SELECT e.sid FROM enrol e) ORDER BY s.id;
