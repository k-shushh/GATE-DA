SELECT id, name FROM student ORDER BY id;
