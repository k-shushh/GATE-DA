SELECT s.name FROM student s WHERE NOT EXISTS (SELECT 1 FROM course c WHERE NOT EXISTS (SELECT 1 FROM enrol e WHERE e.sid=s.id AND e.cid=c.id));
