PRAGMA foreign_keys=ON;
CREATE TABLE student(id INTEGER PRIMARY KEY, name TEXT NOT NULL, city TEXT, score REAL CHECK(score BETWEEN 0 AND 100));
INSERT INTO student VALUES(1,'Asha','Delhi',80),(2,'Bina','Pune',90),(3,'Chen','Delhi',NULL),(4,'Dev','Pune',70);
CREATE TABLE course(id TEXT PRIMARY KEY, title TEXT NOT NULL);
INSERT INTO course VALUES('P','Python'),('D','Databases'),('A','Algorithms');
CREATE TABLE enrol(sid INTEGER REFERENCES student(id), cid TEXT REFERENCES course(id), mark INTEGER, PRIMARY KEY(sid,cid));
INSERT INTO enrol VALUES(1,'P',80),(1,'D',90),(2,'P',95),(2,'D',85),(3,'P',60);
CREATE TABLE sales(city TEXT, month TEXT, product TEXT, revenue INTEGER, units INTEGER);
INSERT INTO sales VALUES('Delhi','Jan','Book',120,3),('Delhi','Feb','Book',80,2),('Pune','Jan','Book',100,2),('Pune','Jan','Pen',60,6);
