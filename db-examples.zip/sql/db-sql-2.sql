SELECT city,COUNT(*) AS students,COUNT(score) AS graded,AVG(score) AS mean FROM student GROUP BY city ORDER BY city;
