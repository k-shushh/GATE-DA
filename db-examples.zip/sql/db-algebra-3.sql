SELECT s.name FROM student s WHERE NOT EXISTS (SELECT 1 FROM course c WHERE c.id IN ('P','D') AND NOT EXISTS (SELECT 1 FROM enrol e WHERE e.sid=s.id AND e.cid=c.id)) ORDER BY s.id;
