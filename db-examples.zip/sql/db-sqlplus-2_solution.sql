WITH counts AS (SELECT sid,COUNT(*) AS n FROM enrol GROUP BY sid) SELECT s.name FROM student s JOIN counts c ON c.sid=s.id WHERE c.n>=2 ORDER BY s.id;
