SELECT city,product,SUM(revenue) AS revenue,SUM(units) AS units FROM sales GROUP BY city,product ORDER BY city,product;
