SELECT SUM(revenue) AS revenue,SUM(units) AS units,ROUND(1.0*SUM(revenue)/SUM(units),2) AS price_per_unit FROM sales;
