SELECT product,SUM(revenue),SUM(units) FROM sales GROUP BY product ORDER BY product;
