SELECT name,score FROM student WHERE score IS NOT NULL ORDER BY score DESC,id LIMIT 2;
