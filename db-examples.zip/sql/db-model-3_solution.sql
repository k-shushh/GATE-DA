SELECT name FROM student WHERE score IS NULL OR score>=90 ORDER BY id;
