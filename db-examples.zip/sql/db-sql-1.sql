SELECT name, score+5 AS adjusted FROM student WHERE score>=70 AND city='Pune' ORDER BY adjusted DESC, id;
