SELECT s.name, c.title, e.mark FROM enrol e JOIN student s ON s.id=e.sid JOIN course c ON c.id=e.cid ORDER BY s.id,c.id;
