SELECT city,AVG(score) FROM student GROUP BY city HAVING AVG(score)>=80 ORDER BY city;
