SELECT c.title FROM course c WHERE NOT EXISTS (SELECT 1 FROM enrol e WHERE e.cid=c.id AND e.sid=3) ORDER BY c.id;
