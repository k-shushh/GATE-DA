GATE Lab database practice
72 Python example/solution files. Run: python filename.py
SQL examples use the standard sqlite3 library, with a fresh in-memory database per run.
Standalone .sql queries can be run after seed.sql in SQLite.
Predict first; compare with the full lesson notes.
