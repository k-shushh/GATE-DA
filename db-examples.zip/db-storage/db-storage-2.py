# 02 · Dense, sparse and secondary indexes
from math import ceil
entries=10000; per_block=100;levels=[]
while True:
    blocks=ceil(entries/per_block);levels.append(blocks)
    if blocks==1:break
    entries=blocks
print('index blocks bottom to top',levels)
print('index levels',len(levels))
