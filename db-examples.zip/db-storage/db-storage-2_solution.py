# 02 · Dense, sparse and secondary indexes
from math import ceil
n=1000000;levels=[]
while True:
    n=ceil(n/100);levels.append(n)
    if n==1:break
print(levels)
