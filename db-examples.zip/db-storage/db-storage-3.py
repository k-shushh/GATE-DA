# 03 · B+ trees, hashing and plan selection
B,K,P=4096,16,8
p=(B+K)//(P+K)
print('max children',p)
print('bytes',p*P+(p-1)*K)
print('next would need',(p+1)*P+p*K)
