# 01 · Page organization and I/O cost
from math import ceil
bfr=1000//300
print(bfr,ceil(10/bfr))
