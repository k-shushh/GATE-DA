# 03 · B+ trees, hashing and plan selection
print((1000+10)//(6+10))
