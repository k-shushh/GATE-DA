# 01 · Page organization and I/O cost
from math import ceil
B,R,N=4096,100,1000
bfr=B//R
print('records/block',bfr)
print('blocks',ceil(N/bfr))
print('unused bytes/block',B-bfr*R)
