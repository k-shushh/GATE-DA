# 01 · Functional dependencies and attribute closure
fds=[(set('A'),set('B')),(set('B'),set('C')),(set('AC'),set('D'))]
c=set('B')
while True:
    old=c.copy()
    for x,y in fds:
        if x<=c:c|=y
    if old==c:break
print(''.join(sorted(c)))
