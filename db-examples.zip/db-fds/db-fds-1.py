# 01 · Functional dependencies and attribute closure
fds=[(set('A'),set('B')),(set('B'),set('C')),(set('AC'),set('D'))]
closure=set('A')
while True:
    old=closure.copy()
    for left,right in fds:
        if left<=closure: closure |= right
    if closure==old: break
print(''.join(sorted(closure)))
