# 02 · Find all candidate keys and a minimal cover
from itertools import combinations
attrs=set('ABC'); fds=[(set('A'),set('B')),(set('B'),set('A'))]
def close(x):
    x=set(x)
    while True:
        old=x.copy()
        for a,b in fds:
            if a<=x:x|=b
        if old==x:return x
keys=[]
for n in range(4):
    for t in combinations(sorted(attrs),n):
        s=set(t)
        if not any(k<=s for k in keys) and close(s)==attrs:keys.append(s)
print([''.join(sorted(k)) for k in keys])
