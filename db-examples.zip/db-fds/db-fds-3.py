# 03 · Lossless joins and dependency preservation
r={('a','b1','c1'),('a','b2','c2')}
ab={(a,b) for a,b,c in r}; ac={(a,c) for a,b,c in r}
joined={(a,b,c) for a,b in ab for a2,c in ac if a==a2}
print('original',len(r),'rejoined',len(joined))
print('spurious',sorted(joined-r))
