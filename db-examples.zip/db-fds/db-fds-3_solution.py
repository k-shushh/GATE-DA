# 03 · Lossless joins and dependency preservation
r={('a1','b','c'),('a2','b','c')}
ab={(a,b) for a,b,c in r};bc={(b,c) for a,b,c in r}
j={(a,b,c) for a,b in ab for b2,c in bc if b==b2}
print(j==r)
