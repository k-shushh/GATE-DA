# 02 · Find all candidate keys and a minimal cover
from itertools import combinations
keys=[]
for n in range(4):
    for t in combinations('ABC',n):
        s=set(t);c=s|({'B'} if 'A' in s else set())
        if c==set('ABC') and not any(k<=s for k in keys):keys.append(s)
print([''.join(sorted(k)) for k in keys])
