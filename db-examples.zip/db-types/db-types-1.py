# 01 · Know what a value means
values=['low','high','medium','low']
order={'low':0,'medium':1,'high':2}
print([order[x] for x in values])
print(sorted(set(values),key=order.get))
