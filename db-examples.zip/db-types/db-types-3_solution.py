# 03 · Encoding, integration and reproducible pipelines
values=[100,250,0]
assert all(x>=0 for x in values)
print([x/100 for x in values])
