# 03 · Encoding, integration and reproducible pipelines
levels=['Delhi','Pune']; rows=['Delhi','Pune','Jaipur']
encoded=[[int(x==c) for c in levels]+[int(x not in levels)] for x in rows]
print('columns',levels+['unknown'])
print(encoded)
