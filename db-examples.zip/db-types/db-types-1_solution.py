# 01 · Know what a value means
cities=['Delhi','Pune','Delhi'];levels=['Delhi','Pune']
print([[int(c==level) for level in levels] for c in cities])
