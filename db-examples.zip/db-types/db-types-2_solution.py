# 02 · Missing values, duplicates and outliers
fill=11.5
print([fill if x is None else x for x in [None,20]])
