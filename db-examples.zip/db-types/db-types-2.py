# 02 · Missing values, duplicates and outliers
from statistics import median
train=[10,None,12,100,11]
fill=median(x for x in train if x is not None)
print('training median',fill)
print([fill if x is None else x for x in train])
