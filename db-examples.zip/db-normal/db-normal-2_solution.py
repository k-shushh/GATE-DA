# 02 · 3NF and BCNF: use the exact conditions
s=set('B');fds=[(set('A'),set('B')),(set('B'),set('C'))]
while True:
    old=s.copy()
    for x,y in fds:
        if x<=s:s|=y
    if old==s:break
print(s==set('ABC'))
