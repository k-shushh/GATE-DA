# 03 · Multivalued dependencies and higher forms
print('cross product',5*7)
print('separate',5+7)
