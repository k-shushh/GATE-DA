# 02 · 3NF and BCNF: use the exact conditions
from itertools import combinations
fds=[(set('AB'),set('C')),(set('C'),set('B'))]
def close(s):
    s=set(s)
    while True:
        old=s.copy()
        for x,y in fds:
            if x<=s:s|=y
        if old==s:return s
print('C closure:', ''.join(sorted(close('C'))))
print('AB closure:', ''.join(sorted(close('AB'))))
print('AC closure:', ''.join(sorted(close('AC'))))
