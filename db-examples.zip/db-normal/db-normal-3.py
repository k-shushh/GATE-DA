# 03 · Multivalued dependencies and higher forms
hobbies={'chess','music'};languages={'Hindi','English'}
wide={(h,l) for h in hobbies for l in languages}
print('wide facts',len(wide))
print('separate facts',len(hobbies)+len(languages))
print(sorted(wide))
