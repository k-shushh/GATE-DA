# 02 · Equal-width and equal-frequency bins
def bucket(x):return min(int(x//50),1)
print([bucket(x) for x in [0,49,50,100]])
