# 02 · Equal-width and equal-frequency bins
from bisect import bisect_right
edges=[0,10,20,30]
def bin_id(x):
    if x<edges[0] or x>edges[-1]:return 'outside'
    return min(bisect_right(edges,x)-1,len(edges)-2)
print([(x,bin_id(x)) for x in [0,9,10,20,30]])
