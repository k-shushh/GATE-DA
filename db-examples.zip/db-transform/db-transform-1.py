# 01 · Min–max, z-score and decimal scaling
from statistics import mean,pstdev
x=[10,20,30]
print('minmax',[(v-min(x))/(max(x)-min(x)) for v in x])
print('z',[round((v-mean(x))/pstdev(x),3) for v in x])
