# 01 · Min–max, z-score and decimal scaling
print((40-10)/(30-10))
