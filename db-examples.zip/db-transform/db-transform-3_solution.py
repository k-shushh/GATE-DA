# 03 · Smoothing, transformations and information loss
from math import log1p
print([round(log1p(x),3) for x in [0,9,99]])
