# 03 · Smoothing, transformations and information loss
from statistics import mean,median
bins=[[2,4,9],[12,13,20]]
print('mean smoothing',[[mean(b)]*len(b) for b in bins])
print('median smoothing',[[median(b)]*len(b) for b in bins])
