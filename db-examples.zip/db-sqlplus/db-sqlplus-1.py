# 01 · Define, change and query safely
import sqlite3
db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE account(id INTEGER PRIMARY KEY, balance INTEGER CHECK(balance>=0))')
db.executemany('INSERT INTO account VALUES(?,?)',[(1,100),(2,50)])
db.commit()
db.execute('UPDATE account SET balance=balance-? WHERE id=?',(30,1))
db.execute('UPDATE account SET balance=balance+? WHERE id=?',(30,2))
db.commit()
print(db.execute('SELECT * FROM account ORDER BY id').fetchall())
