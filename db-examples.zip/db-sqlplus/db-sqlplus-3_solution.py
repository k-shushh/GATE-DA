# 03 · Window functions and an analytical capstone
import sqlite3
db = sqlite3.connect(':memory:')
db.executescript("PRAGMA foreign_keys=ON;\nCREATE TABLE student(id INTEGER PRIMARY KEY, name TEXT NOT NULL, city TEXT, score REAL CHECK(score BETWEEN 0 AND 100));\nINSERT INTO student VALUES(1,'Asha','Delhi',80),(2,'Bina','Pune',90),(3,'Chen','Delhi',NULL),(4,'Dev','Pune',70);\nCREATE TABLE course(id TEXT PRIMARY KEY, title TEXT NOT NULL);\nINSERT INTO course VALUES('P','Python'),('D','Databases'),('A','Algorithms');\nCREATE TABLE enrol(sid INTEGER REFERENCES student(id), cid TEXT REFERENCES course(id), mark INTEGER, PRIMARY KEY(sid,cid));\nINSERT INTO enrol VALUES(1,'P',80),(1,'D',90),(2,'P',95),(2,'D',85),(3,'P',60);\nCREATE TABLE sales(city TEXT, month TEXT, product TEXT, revenue INTEGER, units INTEGER);\nINSERT INTO sales VALUES('Delhi','Jan','Book',120,3),('Delhi','Feb','Book',80,2),('Pune','Jan','Book',100,2),('Pune','Jan','Pen',60,6);")
query = "SELECT city,month,product,revenue,SUM(revenue) OVER(PARTITION BY city) AS city_total,ROUND(1.0*revenue/SUM(revenue) OVER(PARTITION BY city),2) AS share FROM sales ORDER BY city,month,product;"
rows = db.execute(query).fetchall()
if not rows: print('(no rows)')
for row in rows:
    print(row)
