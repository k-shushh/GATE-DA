# 01 · Define, change and query safely
import sqlite3
db=sqlite3.connect(':memory:')
db.execute('CREATE TABLE t(x INTEGER)')
db.execute('INSERT INTO t VALUES(?)',(7,))
db.rollback()
print(db.execute('SELECT COUNT(*) FROM t').fetchone()[0])
