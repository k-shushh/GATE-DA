# 03 · Lossless and lossy compression
x=[100,103,109,110]
d=[x[0]]+[b-a for a,b in zip(x,x[1:])]
print(d)
from itertools import accumulate
print(list(accumulate(d)))
