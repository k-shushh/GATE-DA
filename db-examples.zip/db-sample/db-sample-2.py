# 02 · Reservoir sampling and estimator checks
import random
def reservoir(stream,k,seed=7):
    if k<0:raise ValueError('k must be nonnegative')
    r=random.Random(seed);out=[]
    for i,x in enumerate(stream,1):
        if i<=k:out.append(x)
        else:
            j=r.randrange(i)
            if j<k:out[j]=x
    return out
print(reservoir(range(100),5))
print(reservoir(range(3),5))
