# 01 · Random, stratified, cluster and systematic samples
import random
r=random.Random(7)
groups={'A':[1,2,3,4],'B':[5,6,7,8]}
print({k:r.sample(v,2) for k,v in groups.items()})
