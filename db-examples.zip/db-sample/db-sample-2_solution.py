# 02 · Reservoir sampling and estimator checks
print(5/100)
