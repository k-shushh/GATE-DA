# 03 · Lossless and lossy compression
from itertools import groupby
x='AAAABBBCCAAAA'
encoded=[(symbol,len(list(run))) for symbol,run in groupby(x)]
decoded=''.join(symbol*n for symbol,n in encoded)
print(encoded)
print(decoded==x)
