# 01 · Random, stratified, cluster and systematic samples
import random
rng=random.Random(7)
population=list(range(10))
sample=rng.sample(population,4)
print(sample)
print('unique',len(set(sample))==4)
