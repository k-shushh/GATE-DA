# 03 · Continuity and its consequences
import math
f=lambda x: 1 if x==0 else math.sin(x)/x
print(f(0),f(.001))
