# 03 · Exponential, logarithmic and trigonometric essentials
import math
x=.1
print(math.sin(x),x)
print(math.cos(x),1-x*x/2)
