# 02 · Remainders and where a series works
import math
print(abs(math.sin(.1)-.1),.1**3/6)
