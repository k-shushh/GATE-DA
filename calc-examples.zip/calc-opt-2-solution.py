# 02 · Turn a word problem into one variable
f=lambda x:x+9/x
print(f(3))
print(1-9/3**2,18/3**3)
