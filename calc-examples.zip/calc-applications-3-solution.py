# 03 · Related rates and local error estimates
import math
print(12*math.pi)
