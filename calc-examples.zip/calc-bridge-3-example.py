# 03 · A capstone: fit a line and explain the loss
import numpy as np
np.set_printoptions(precision=4, suppress=True)
t=np.array([0.,1.,2.]);y=np.array([1.,2.,2.])
X=np.column_stack([np.ones(3),t])
beta=np.linalg.lstsq(X,y,rcond=None)[0]
r=y-X@beta
print(beta)
print(r)
print(X.T@r)
