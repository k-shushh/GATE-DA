# 02 · Turn a word problem into one variable
A=lambda x:x*(10-x)
print(A(0),A(5),A(10))
