# 02 · Partial derivatives, gradients and Hessians
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,4.]])
x=np.array([1.,2.])
print('gradient',A@x)
print('curvatures',np.linalg.eigvalsh(A))
