# 02 · Sign charts, concavity and inflection
for x in [-2,0,2]: print(x,3*(x*x-1),6*x)
