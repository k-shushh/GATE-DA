# 03 · Gradient descent, Newton steps and stopping
x=0.
for k in range(5):
    x-=.25*2*(x-3)
    print(k+1,x,(x-3)**2)
