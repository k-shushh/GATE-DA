# 01 · What a limit really says
import math
for x in [.1,.01,.001]: print(x*x*math.cos(1/x))
