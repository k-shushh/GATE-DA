# 03 · Leading terms, limits and flat stationary points
import math
for x in [.1,.01,.001]: print((math.expm1(x)-x)/(x*x))
