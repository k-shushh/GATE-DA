# 01 · Rolle’s theorem and the mean value theorem
import math
c=2/math.sqrt(3)
print(c,3*c*c)
