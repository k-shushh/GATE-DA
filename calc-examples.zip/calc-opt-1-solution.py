# 01 · Local tests and global extrema
f=lambda x:abs(x-1)
print([(x,f(x)) for x in [0,1,3]])
