# 01 · Functions, domains and graphs
def f(x):
    if x == 1: return 'undefined'
    return (x*x-1)/(x-1)
print([f(x) for x in [0,1,2]])
