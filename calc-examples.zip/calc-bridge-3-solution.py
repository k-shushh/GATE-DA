# 03 · A capstone: fit a line and explain the loss
import numpy as np
np.set_printoptions(precision=4, suppress=True)
y=np.array([2.,4.,9.])
c=np.mean(y)
print(c,y-c,np.sum(y-c))
