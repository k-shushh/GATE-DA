# 03 · Implicit, logarithmic and higher differentiation
print(-3/4)
second_derivative=lambda x: 12*x*x
print(second_derivative(2))
