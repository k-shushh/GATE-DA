# 02 · Sign charts, concavity and inflection
for x in [-1,0,1]: print(x,12*x*x)
