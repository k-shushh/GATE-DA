# 02 · The derivative toolkit
import math
df=lambda x: math.exp(3*x)*(2*x+3*x*x)
print(df(1))
