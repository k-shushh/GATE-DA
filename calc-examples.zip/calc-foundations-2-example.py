# 02 · Composition, inverses and algebraic preparation
import math
f=lambda t: math.sqrt(t)
g=lambda x: x-2
print(f(g(6)),g(f(9)))
