# 03 · Exponential, logarithmic and trigonometric essentials
import math
print(math.log(math.exp(2)*math.sqrt(math.e)))
print(math.sin(.01))
