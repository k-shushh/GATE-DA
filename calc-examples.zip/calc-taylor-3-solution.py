# 03 · Leading terms, limits and flat stationary points
for x in [-.1,0,.1]: print(x,x**6,x**5)
