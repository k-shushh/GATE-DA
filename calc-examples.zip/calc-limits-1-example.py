# 01 · What a limit really says
for x in [.9,.99,1.01,1.1]:
    print(x,(x*x-1)/(x-1))
