# 02 · Remainders and where a series works
import math
x=.1
err=math.exp(x)-(1+x+x*x/2)
bound=math.exp(x)*x**3/6
print(err,bound,err<=bound)
