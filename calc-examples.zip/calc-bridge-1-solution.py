# 01 · Integration recap: accumulation and area
import math
print(math.e-1)
