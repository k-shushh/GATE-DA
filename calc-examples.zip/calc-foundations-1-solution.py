# 01 · Functions, domains and graphs
import math
for x in [2,3,5]:
    print(x, math.log(x-2)/math.sqrt(5-x) if 2<x<5 else 'outside domain')
