# 03 · Gradient descent, Newton steps and stopping
for eta in [.1,.4,.5,.6]:
    factor=1-4*eta
    print(eta,factor,abs(factor)<1)
