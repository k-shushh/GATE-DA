# 03 · Related rates and local error estimates
import math
approx=2+.25*.04
print(approx,math.sqrt(4.04),approx-math.sqrt(4.04))
