# 01 · Constructing a Taylor polynomial
x=.2
print(1-x*x/2+x**4/24)
