# 02 · Partial derivatives, gradients and Hessians
import numpy as np
np.set_printoptions(precision=4, suppress=True)
H=np.diag([2.,-2.])
print(np.linalg.eigvalsh(H))
