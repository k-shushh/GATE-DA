# 01 · Integration recap: accumulation and area
for n in [10,100,1000]:
    print(n,sum(((i+.5)/n)**2/n for i in range(n)))
