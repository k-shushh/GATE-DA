# 03 · Continuity and its consequences
k=1
for x in [1.99,2,2.01]: print(x,k*x+1 if x<2 else x*x-1)
