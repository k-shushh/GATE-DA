# 01 · Constructing a Taylor polynomial
import math
x=.2
T=sum(x**k/math.factorial(k) for k in range(4))
print(T,math.exp(x),math.exp(x)-T)
