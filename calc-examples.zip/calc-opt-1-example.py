# 01 · Local tests and global extrema
f=lambda x:x**3-3*x
print([(x,f(x)) for x in [-2,-1,1,2]])
