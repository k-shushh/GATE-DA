# 02 · Composition, inverses and algebraic preparation
import math
inverse=lambda y: math.sqrt(y-1)
print(inverse(10))
