# 02 · The derivative toolkit
df=lambda x: 2*x/(1+x*x)
print(df(1))
