# 01 · Derivative as a limiting slope
for h in [.1,.01,.001]: print(((1+h)**3-1)/h)
