# 01 · Rolle’s theorem and the mean value theorem
print((3**2-1**2)/(3-1))
print(2*2)
