# 02 · Standard limits and indeterminate forms
import math
for x in [.1,.01,.001]: print(math.expm1(3*x)/math.sin(2*x))
