# 02 · Standard limits and indeterminate forms
import math
for x in [.1,.01,.001]: print(2*math.sin(x)**2/(x*x))
