# 01 · Derivative as a limiting slope
for h in [1,.1,.01,.001]: print(h,((2+h)**2-4)/h)
