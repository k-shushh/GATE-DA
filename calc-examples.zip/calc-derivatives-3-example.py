# 03 · Implicit, logarithmic and higher differentiation
import math
for x in [1,2]: print(x,x**x*(math.log(x)+1))
