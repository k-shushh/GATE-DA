# Complete recursive quicksort using this Lomuto partition.

def sort(a,lo,hi):
    if lo>=hi: return
    p=a[hi]; i=lo
    for j in range(lo,hi):
        if a[j]<=p: a[i],a[j]=a[j],a[i]; i+=1
    a[i],a[hi]=a[hi],a[i]
    sort(a,lo,i-1); sort(a,i+1,hi)
a=[4,2,5,1,3]; sort(a,0,len(a)-1)
assert a==[1,2,3,4,5]
