# 01 · Merge two sorted sequences and build merge sort

def merge_sort(a):
    if len(a)<2: return a[:]
    mid=len(a)//2
    left,right=merge_sort(a[:mid]),merge_sort(a[mid:])
    out=[]; i=j=0
    while i<len(left) and j<len(right):
        if left[i]<=right[j]: out.append(left[i]); i+=1
        else: out.append(right[j]); j+=1
    return out+left[i:]+right[j:]
print(merge_sort([5,1,3,1]))
