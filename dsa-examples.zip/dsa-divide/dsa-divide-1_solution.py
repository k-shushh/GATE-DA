# Merge [1,4,8] and [2,4,9] iteratively.

a,b=[1,4,8],[2,4,9]; i=j=0; out=[]
while i<len(a) and j<len(b):
    if a[i]<=b[j]: out.append(a[i]); i+=1
    else: out.append(b[j]); j+=1
out+=a[i:]+b[j:]
assert out==[1,2,4,4,8,9]
