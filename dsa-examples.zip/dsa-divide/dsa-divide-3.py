# 03 · Duplicates, lower bounds and choosing a sort

a=[3,1,3,2,3,4]
pivot=3
less=[x for x in a if x<pivot]
equal=[x for x in a if x==pivot]
greater=[x for x in a if x>pivot]
print(less,equal,greater)
