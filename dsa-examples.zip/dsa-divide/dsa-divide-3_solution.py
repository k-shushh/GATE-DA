# Counting-sort nonnegative keys [3,1,3,0,2] with maximum 3.

a=[3,1,3,0,2]; count=[0]*4
for x in a: count[x]+=1
out=[x for x,c in enumerate(count) for _ in range(c)]
assert out==[0,1,2,3,3]
