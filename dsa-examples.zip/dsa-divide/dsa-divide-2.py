# 02 · Quicksort and Lomuto partition

def partition(a,lo,hi):
    pivot=a[hi]; i=lo
    for j in range(lo,hi):
        if a[j]<=pivot:
            a[i],a[j]=a[j],a[i]; i+=1
    a[i],a[hi]=a[hi],a[i]
    return i
a=[4,2,5,1,3]
p=partition(a,0,len(a)-1)
print(a,p)
