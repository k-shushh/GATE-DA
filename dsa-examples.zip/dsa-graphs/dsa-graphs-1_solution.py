# Compute maximum edges for a simple undirected graph with 6 vertices.

n=6
assert n*(n-1)//2==15
