# 01 · Graph vocabulary and counting facts

edges=[(0,1),(1,2),(2,3),(3,0)]
degree=[0]*4
for u,v in edges:
    degree[u]+=1; degree[v]+=1
print(degree,sum(degree),2*len(edges))
