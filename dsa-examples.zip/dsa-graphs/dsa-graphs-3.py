# 03 · Reachability, components and bipartite colouring

from collections import deque
def bipartite(adj):
    colour={}
    for start in range(len(adj)):
        if start in colour: continue
        colour[start]=0; q=deque([start])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if v not in colour: colour[v]=1-colour[u]; q.append(v)
                elif colour[v]==colour[u]: return False
    return True
print(bipartite([[1,2],[0,2],[0,1]]))
print(bipartite([[1,3],[0,2],[1,3],[0,2]]))
