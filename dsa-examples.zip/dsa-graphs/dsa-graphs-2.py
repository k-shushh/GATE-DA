# 02 · Adjacency lists, matrices and edge lists

n=4
edges=[(0,1),(1,2)]
adj=[[] for _ in range(n)]
mat=[[False]*n for _ in range(n)]
for u,v in edges:
    adj[u].append(v); adj[v].append(u)
    mat[u][v]=mat[v][u]=True
print(adj)
print(mat[0][2],mat[1][2])
