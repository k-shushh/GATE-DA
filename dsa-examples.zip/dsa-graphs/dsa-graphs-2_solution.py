# Build directed adjacency lists for 0->1 and 2->1.

adj=[[] for _ in range(3)]
for u,v in [(0,1),(2,1)]: adj[u].append(v)
assert adj==[[1],[],[1]]
