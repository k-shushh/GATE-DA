# Count components of the undirected graph [[1],[0],[]].

adj=[[1],[0],[]]; seen=set(); components=0
for s in range(len(adj)):
    if s in seen: continue
    components+=1; stack=[s]; seen.add(s)
    while stack:
        for v in adj[stack.pop()]:
            if v not in seen: seen.add(v); stack.append(v)
assert components==2
