# 03 · Build a route planner and an exam-solving workflow

import heapq
def route(graph,source,target):
    d={source:0}; parent={source:None}; heap=[(0,source)]
    while heap:
        cost,u=heapq.heappop(heap)
        if cost!=d[u]: continue
        if u==target: break
        for v,w in graph[u]:
            if w<0: raise ValueError('nonnegative weights required')
            if cost+w<d.get(v,float('inf')):
                d[v]=cost+w; parent[v]=u; heapq.heappush(heap,(d[v],v))
    if target not in d: return None
    path=[]; u=target
    while u is not None: path.append(u); u=parent[u]
    return d[target],path[::-1]
g={'A':[('B',5),('C',1)],'B':[('D',2)],'C':[('B',2)],'D':[],'E':[]}
print(route(g,'A','D'))
print(route(g,'A','E'))
