# 01 · Greedy methods, disjoint sets and minimum spanning trees

edges=[(1,0,1),(2,1,2),(5,0,2),(3,2,3)]
parent=list(range(4)); size=[1]*4
def find(x):
    while x!=parent[x]: parent[x]=parent[parent[x]]; x=parent[x]
    return x
total=0; chosen=[]
for w,u,v in sorted(edges):
    a,b=find(u),find(v)
    if a==b: continue
    if size[a]<size[b]: a,b=b,a
    parent[b]=a; size[a]+=size[b]; total+=w; chosen.append((u,v))
print(total,chosen)
