# Add input validation that rejects negative weights anywhere in the graph.

def validate_graph(g):
    for u,edges in g.items():
        for v,w in edges:
            if v not in g or w<0: raise ValueError('invalid graph')
    return True
assert validate_graph({'A':[('B',2)],'B':[]})
try: validate_graph({'A':[],'B':[('B',-1)]})
except ValueError: pass
else: raise AssertionError('negative edge was missed')
