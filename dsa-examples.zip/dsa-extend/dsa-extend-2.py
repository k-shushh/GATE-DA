# 02 · Dynamic programming and backtracking

coins=[1,3,4]; amount=6
dp=[0]+[float('inf')]*amount
for s in range(1,amount+1):
    for c in coins:
        if c<=s: dp[s]=min(dp[s],1+dp[s-c])
print(dp)
print(dp[amount])
