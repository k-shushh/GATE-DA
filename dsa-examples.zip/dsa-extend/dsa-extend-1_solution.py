# Show the greedy coin counterexample for target6 using coins1,3,4.

remaining=6; used=[]
for coin in [4,3,1]:
    while remaining>=coin: used.append(coin); remaining-=coin
assert len(used)==3 and 3+3==6
