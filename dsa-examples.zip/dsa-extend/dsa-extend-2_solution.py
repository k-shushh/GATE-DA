# Generate all subsets of [1,2,3] iteratively.

subsets=[[]]
for x in [1,2,3]: subsets += [s+[x] for s in subsets]
assert len(subsets)==8 and [1,2,3] in subsets
