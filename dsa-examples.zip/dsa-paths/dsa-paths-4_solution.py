# Use 0–1 BFS to find distances in0->1(1),0->2(0),2->1(0).

from collections import deque
a=[[(1,1),(2,0)],[],[(1,0)]]; d=[0,float('inf'),float('inf')]; q=deque([0])
while q:
    u=q.popleft()
    for v,w in a[u]:
        if d[u]+w<d[v]:
            d[v]=d[u]+w
            if w==0: q.appendleft(v)
            else: q.append(v)
assert d==[0,0,0]
