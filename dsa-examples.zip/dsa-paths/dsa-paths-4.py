# 04 · DAG paths, 0–1 BFS and choosing the right method

adj=[[(1,2),(2,5)],[(2,-4)],[]]
order=[0,1,2]
d=[0,float('inf'),float('inf')]
for u in order:
    for v,w in adj[u]: d[v]=min(d[v],d[u]+w)
print(d)
