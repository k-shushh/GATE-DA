# 03 · Floyd–Warshall for all pairs

inf=float('inf')
d=[[0,4,10],[inf,0,3],[inf,inf,0]]
for k in range(3):
    for i in range(3):
        for j in range(3):
            d[i][j]=min(d[i][j],d[i][k]+d[k][j])
print(d[0][2])
print(any(d[i][i]<0 for i in range(3)))
