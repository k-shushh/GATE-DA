# 02 · Bellman–Ford and negative-cycle detection

edges=[(0,1,4),(0,2,5),(1,2,-2),(2,3,3)]
n=4; d=[float('inf')]*n; d[0]=0
for _ in range(n-1):
    changed=False
    for u,v,w in edges:
        if d[u]+w<d[v]: d[v]=d[u]+w; changed=True
    if not changed: break
negative=any(d[u]+w<d[v] for u,v,w in edges)
print(d,negative)
