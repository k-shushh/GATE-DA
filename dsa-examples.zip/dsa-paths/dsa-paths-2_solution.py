# Detect the reachable negative cycle0->1 weight 1,1->2 weight-3,2->1 weight 1.

e=[(0,1,1),(1,2,-3),(2,1,1)]; d=[0,float('inf'),float('inf')]
for _ in range(2):
    for u,v,w in e:
        if d[u]+w<d[v]: d[v]=d[u]+w
assert any(d[u]+w<d[v] for u,v,w in e)
