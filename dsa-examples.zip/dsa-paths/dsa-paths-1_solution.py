# Use relaxation to compare direct cost 10 with a path of edges3 and 4.

d={'s':0,'a':3,'t':10}
if d['a']+4<d['t']: d['t']=d['a']+4
assert d['t']==7
