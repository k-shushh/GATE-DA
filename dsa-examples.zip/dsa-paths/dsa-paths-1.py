# 01 · Relaxation, path reconstruction and Dijkstra

import heapq
adj=[[(1,4),(2,1)],[(3,1)],[(1,2),(3,5)],[]]
d=[float('inf')]*4; d[0]=0; heap=[(0,0)]
while heap:
    du,u=heapq.heappop(heap)
    if du!=d[u]: continue
    for v,w in adj[u]:
        if du+w<d[v]:
            d[v]=du+w; heapq.heappush(heap,(d[v],v))
print(d)
