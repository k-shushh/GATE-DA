# Compute reachability closure for 0->1->2 with Boolean Warshall.

r=[[True,True,False],[False,True,True],[False,False,True]]
for k in range(3):
    for i in range(3):
        for j in range(3): r[i][j]=r[i][j] or (r[i][k] and r[k][j])
assert r[0][2]
