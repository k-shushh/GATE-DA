# Change neighbour order at 0 to[2,1] and predict parent[3].

from collections import deque
a=[[2,1],[3],[3],[]]; p={0:None}; q=deque([0])
while q:
    u=q.popleft()
    for v in a[u]:
        if v not in p: p[v]=u; q.append(v)
assert p[3]==2
