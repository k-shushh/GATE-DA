# 02 · Depth-first search, finishing times and cycles

adj=[[1,2],[2],[0],[]]
colour=[0]*4; order=[]; cycle=False
def dfs(u):
    global cycle
    colour[u]=1; order.append(u)
    for v in adj[u]:
        if colour[v]==0: dfs(v)
        elif colour[v]==1: cycle=True
    colour[u]=2
for u in range(4):
    if colour[u]==0: dfs(u)
print(order,cycle)
