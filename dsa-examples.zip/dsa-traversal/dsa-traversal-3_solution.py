# Validate [1,0,2,3] against edges0->2,1->2,2->3.

order=[1,0,2,3]; pos={v:i for i,v in enumerate(order)}
assert all(pos[u]<pos[v] for u,v in [(0,2),(1,2),(2,3)])
