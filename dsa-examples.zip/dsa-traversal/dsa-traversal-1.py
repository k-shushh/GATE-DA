# 01 · Breadth-first search and shortest-hop paths

from collections import deque
adj=[[1,2],[3],[3],[]]
dist=[-1]*4; parent=[None]*4
dist[0]=0; q=deque([0])
while q:
    u=q.popleft()
    for v in adj[u]:
        if dist[v]==-1:
            dist[v]=dist[u]+1; parent[v]=u; q.append(v)
path=[]; v=3
while v is not None: path.append(v); v=parent[v]
print(dist)
print(path[::-1])
