# 03 · Topological sorting and dependency scheduling

from collections import deque
adj=[[2],[2],[3],[]]
indeg=[0]*4
for row in adj:
    for v in row: indeg[v]+=1
q=deque(i for i,d in enumerate(indeg) if d==0); order=[]
while q:
    u=q.popleft(); order.append(u)
    for v in adj[u]:
        indeg[v]-=1
        if indeg[v]==0: q.append(v)
print(order,len(order)==len(adj))
