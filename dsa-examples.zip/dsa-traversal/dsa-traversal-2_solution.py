# Trace recursive preorder DFS on 0->[1,2],1->[3],2->[],3->[].

a=[[1,2],[3],[],[]]; seen=set(); order=[]
def dfs(u):
    seen.add(u); order.append(u)
    for v in a[u]:
        if v not in seen: dfs(v)
dfs(0)
assert order==[0,1,3,2]
