# Implement upper bound and count occurrences of 3 in [1,3,3,3,7].

from bisect import bisect_left, bisect_right
a=[1,3,3,3,7]
assert bisect_right(a,3)-bisect_left(a,3)==3
lo,hi=0,len(a)
while lo<hi:
    mid=(lo+hi)//2
    if a[mid]<=3: lo=mid+1
    else: hi=mid
assert lo==4
