# 01 · Linear search and sentinels

def find_first(a,x):
    for i,value in enumerate(a):
        if value==x: return i
    return None
print(find_first([9,2,9],9))
print(find_first([],9))
