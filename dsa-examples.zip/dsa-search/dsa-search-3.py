# 03 · Lower bounds, duplicates and binary search on answers

def lower(a,x):
    lo,hi=0,len(a)
    while lo<hi:
        mid=(lo+hi)//2
        if a[mid]<x: lo=mid+1
        else: hi=mid
    return lo
print(lower([1,3,3,3,7],3), lower([1,3,3,3,7],9))
