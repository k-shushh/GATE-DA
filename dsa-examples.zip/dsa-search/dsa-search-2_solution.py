# Record the middle indices when searching for 12 in [1,3,5,8,12].

a=[1,3,5,8,12]; lo,hi=0,4; trace=[]
while lo<=hi:
    mid=(lo+hi)//2; trace.append(mid)
    if a[mid]==12: break
    if a[mid]<12: lo=mid+1
    else: hi=mid-1
assert trace==[2,3,4]
