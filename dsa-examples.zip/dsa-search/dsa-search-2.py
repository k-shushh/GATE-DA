# 02 · Binary search with a precise invariant

def binary_search(a,x):
    lo,hi=0,len(a)-1
    while lo<=hi:
        mid=(lo+hi)//2
        if a[mid]==x: return mid
        if a[mid]<x: lo=mid+1
        else: hi=mid-1
    return None
print(binary_search([1,3,5,8,12],8))
print(binary_search([1,3,5],4))
