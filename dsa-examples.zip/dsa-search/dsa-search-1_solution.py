# Return every matching index of 2 in [2,4,2,2].

a=[2,4,2,2]
indices=[i for i,x in enumerate(a) if x==2]
assert indices==[0,2,3]
