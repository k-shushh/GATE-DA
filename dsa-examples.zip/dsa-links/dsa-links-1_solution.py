# Build the chain 5 -> 7 -> 9 by prepending values in reverse order.

class Node:
    def __init__(self,x,n=None): self.value,self.next=x,n
head=None
for x in [9,7,5]: head=Node(x,head)
a=[]
while head: a.append(head.value); head=head.next
assert a==[5,7,9]
