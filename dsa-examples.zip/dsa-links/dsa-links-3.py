# 03 · Fast/slow pointers and cycle detection

class Node:
    def __init__(self,x): self.value,self.next=x,None
a,b,c=Node(1),Node(2),Node(3)
a.next,b.next,c.next=b,c,b
slow=fast=a
while fast and fast.next:
    slow,fast=slow.next,fast.next.next
    if slow is fast: break
p=a
while p is not slow: p,slow=p.next,slow.next
print(p.value)
