# 01 · Nodes, head pointers and insertion

class Node:
    def __init__(self, value, nxt=None): self.value,self.next=value,nxt
head = Node(2, Node(4))
head = Node(1, head)
head.next.next = Node(3, head.next.next)
values=[]
p=head
while p:
    values.append(p.value)
    p=p.next
print(values)
