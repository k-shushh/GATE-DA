# Remove the first node with value 2 from 1 -> 2 -> 3 using a sentinel.

class Node:
    def __init__(self,x,n=None): self.value,self.next=x,n
dummy=Node(None,Node(1,Node(2,Node(3))))
p=dummy
while p.next and p.next.value!=2: p=p.next
if p.next: p.next=p.next.next
out=[]; p=dummy.next
while p: out.append(p.value); p=p.next
assert out==[1,3]
