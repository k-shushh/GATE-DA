# Find the second middle of [1,2,3,4] using slow/fast pointers.

class Node:
    def __init__(self,x,n=None): self.value,self.next=x,n
h=Node(1,Node(2,Node(3,Node(4))))
slow=fast=h
while fast and fast.next: slow,fast=slow.next,fast.next.next
assert slow.value==3
