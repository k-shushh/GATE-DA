# 02 · Deletion and iterative reversal

class Node:
    def __init__(self,x,n=None): self.value,self.next=x,n
head=Node(1,Node(2,Node(3)))
prev,cur=None,head
while cur:
    nxt=cur.next
    cur.next=prev
    prev,cur=cur,nxt
head=prev
out=[]
while head: out.append(head.value); head=head.next
print(out)
