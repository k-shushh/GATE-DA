# Answer inclusive range [1,2] using prefix sums.

a = [4, -1, 6, 2]
p = [0]
for x in a: p.append(p[-1]+x)
l, r = 1, 2
assert p[r+1]-p[l] == 5
