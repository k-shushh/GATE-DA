# Use deque to enqueue 4,5, remove 4, add 6 and list the queue.

from collections import deque
q = deque([4,5])
assert q.popleft()==4
q.append(6)
assert list(q)==[5,6]
