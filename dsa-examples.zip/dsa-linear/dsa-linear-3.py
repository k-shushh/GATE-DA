# 03 · Queues, circular buffers and deques

capacity = 3
buf = [None]*capacity
head, size = 0, 0
for x in [10,20,30]:
    buf[(head+size)%capacity] = x
    size += 1
head = (head+1)%capacity
size -= 1
buf[(head+size)%capacity] = 40
size += 1
print([buf[(head+i)%capacity] for i in range(size)])
