# 02 · Stacks: LIFO and expression processing

def balanced(text):
    stack = []
    matching = {')':'(', ']':'[', '}':'{'}
    for ch in text:
        if ch in '([{': stack.append(ch)
        elif ch in matching:
            if not stack or stack.pop() != matching[ch]: return False
    return not stack
print(balanced('([{}])'), balanced('([)]'))
