# 01 · Arrays, dynamic lists and operation costs

a = [4, -1, 6, 2]
p = [0]
for x in a: p.append(p[-1] + x)
print(p)
print(p[4] - p[1])
