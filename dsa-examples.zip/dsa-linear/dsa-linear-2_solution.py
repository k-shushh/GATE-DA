# Evaluate postfix tokens 8 3 - 2 * with a stack.

s=[]
for token in ['8','3','-','2','*']:
    if token not in ('-','*'): s.append(int(token))
    else:
        right,left=s.pop(),s.pop()
        s.append(left-right if token=='-' else left*right)
assert s == [10]
