# Delete 7 from its chain and confirm 17 remains.

b=[[] for _ in range(5)]
for x in [12,7,20,17]: b[x%5].append(x)
b[7%5].remove(7)
assert b[2]==[12,17]
