# 03 · Deletion tombstones and practical frequency maps

def two_sum(a, target):
    seen={}
    for i,x in enumerate(a):
        if target-x in seen: return seen[target-x],i
        seen[x]=i
    return None
print(two_sum([3,3,8],6))
print(two_sum([3],6))
