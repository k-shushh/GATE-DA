# Count frequencies of a,b,a,c,b,a.

counts={}
for x in ['a','b','a','c','b','a']: counts[x]=counts.get(x,0)+1
assert counts=={'a':3,'b':2,'c':1}
