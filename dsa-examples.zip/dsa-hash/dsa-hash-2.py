# 02 · Linear, quadratic and double probing

m=7
table=[None]*m
for key in [10,17,24,5]:
    for i in range(m):
        slot=(key % m+i)%m
        if table[slot] is None:
            table[slot]=key
            break
print(table)
