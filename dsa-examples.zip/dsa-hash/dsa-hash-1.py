# 01 · Hash functions, load factor and chaining

m=5
buckets=[[] for _ in range(m)]
for key in [12,7,20,17]: buckets[key % m].append(key)
print(buckets)
print(17 in buckets[17 % m])
