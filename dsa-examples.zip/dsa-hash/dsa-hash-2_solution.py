# List a double-hash probe sequence for m=7, h1=3, h2=2.

slots=[(3+i*2)%7 for i in range(7)]
assert len(set(slots))==7
print(slots)
