# 02 · Asymptotic analysis and loop counting

n = 5
pairs = 0
for i in range(n):
    for j in range(i): pairs += 1
x, steps = 1, 0
while x < n:
    x *= 2
    steps += 1
print(pairs, steps)
