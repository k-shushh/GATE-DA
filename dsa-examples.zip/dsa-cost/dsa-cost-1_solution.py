# Implement minimum with the same contract without slicing.

def minimum(a):
    if not a: raise ValueError("empty input")
    best = a[0]
    for i in range(1, len(a)):
        if a[i] < best: best = a[i]
    return best
assert minimum([-8, -3, -10]) == -10
