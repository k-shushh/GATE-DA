# 03 · Recurrences, stack space and amortisation

def depth(n):
    if n <= 1: return 1
    return 1 + depth(n // 2)
print(depth(16))
capacity, copies = 1, 0
for size in range(8):
    if size == capacity:
        copies += size
        capacity *= 2
print(capacity, copies)
