# Count all ordered pairs i,j with 0 <= i,j < n for n=5.

n = 5
count = sum(1 for i in range(n) for j in range(n))
assert count == n*n
print(count)
