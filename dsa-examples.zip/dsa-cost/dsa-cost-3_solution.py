# Write a recurrence for two half-sized calls doing n merge operations and compute total merge work for n=8.

def work(n):
    if n <= 1: return 0
    return 2*work(n//2) + n
assert work(8) == 24
print(work(8))
