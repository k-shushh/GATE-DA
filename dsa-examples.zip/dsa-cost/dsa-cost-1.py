# 01 · From a problem to a correct algorithm

def maximum(a):
    if not a:
        raise ValueError("empty input")
    best = a[0]
    for x in a[1:]:
        best = max(best, x)
    return best
print(maximum([-8, -3, -10]))
