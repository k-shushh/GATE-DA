# 02 · Bubble sort and early termination

a=[3,1,2]
swaps=0
for end in range(len(a)-1,0,-1):
    changed=False
    for j in range(end):
        if a[j]>a[j+1]:
            a[j],a[j+1]=a[j+1],a[j]
            changed=True; swaps+=1
    if not changed: break
print(a,swaps)
