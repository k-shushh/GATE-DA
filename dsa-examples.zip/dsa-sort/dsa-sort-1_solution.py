# Count selection-sort key comparisons for n=6.

n=6
comparisons=sum(n-i-1 for i in range(n-1))
assert comparisons==15
