# 01 · Selection sort and sorting vocabulary

a=[4,2,3,1]
for i in range(len(a)-1):
    k=i
    for j in range(i+1,len(a)):
        if a[j]<a[k]: k=j
    a[i],a[k]=a[k],a[i]
    print(a)
