# List strict inversion pairs for [3,1,2,1].

a=[3,1,2,1]
pairs=[(i,j) for i in range(len(a)) for j in range(i+1,len(a)) if a[i]>a[j]]
assert len(pairs)==4
print(pairs)
