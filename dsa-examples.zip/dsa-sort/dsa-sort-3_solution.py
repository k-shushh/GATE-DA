# Count insertion shifts for reverse input [4,3,2,1].

a=[4,3,2,1]; shifts=0
for i in range(1,len(a)):
    key=a[i]; j=i-1
    while j>=0 and a[j]>key:
        a[j+1]=a[j]; j-=1; shifts+=1
    a[j+1]=key
assert shifts==6 and a==[1,2,3,4]
