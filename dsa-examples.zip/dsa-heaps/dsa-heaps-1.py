# 01 · Binary heaps and sift operations

import heapq
h=[]
for x in [7,2,9,1]: heapq.heappush(h,x)
print(h[0])
print([heapq.heappop(h) for _ in range(len(h))])
