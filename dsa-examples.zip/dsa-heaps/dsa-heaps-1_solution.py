# Keep the largest three values of [4,8,1,7,6] in a min-heap.

import heapq
h=[]
for x in [4,8,1,7,6]:
    heapq.heappush(h,x)
    if len(h)>3: heapq.heappop(h)
assert sorted(h)==[6,7,8]
