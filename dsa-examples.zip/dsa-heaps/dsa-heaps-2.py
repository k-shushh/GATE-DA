# 02 · Bottom-up heap construction and heapsort

def sift(a,i,n):
    while 2*i+1<n:
        c=2*i+1
        if c+1<n and a[c+1]>a[c]: c+=1
        if a[i]>=a[c]: break
        a[i],a[c]=a[c],a[i]; i=c
a=[4,1,3,2]
for i in range(len(a)//2-1,-1,-1): sift(a,i,len(a))
for end in range(len(a)-1,0,-1):
    a[0],a[end]=a[end],a[0]
    sift(a,0,end)
print(a)
