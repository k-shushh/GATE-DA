# Heapify [9,1,5,2] with heapq and verify each parent is no larger than its children.

import heapq
a=[9,1,5,2]; heapq.heapify(a)
assert all(a[(i-1)//2]<=a[i] for i in range(1,len(a)))
