# Reconstruct the root and left/right inorder segments for preorder A B D E C and inorder D B E A C.

pre=list('ABDEC'); ino=list('DBEAC')
root=pre[0]; split=ino.index(root)
assert root=='A' and ino[:split]==list('DBE') and ino[split+1:]==['C']
