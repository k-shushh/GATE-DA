# 03 · BST deletion, successor and balanced-tree ideas

def delete(t,key):
    if t is None: return None
    k,left,right=t
    if key<k: return (k,delete(left,key),right)
    if key>k: return (k,left,delete(right,key))
    if left is None: return right
    if right is None: return left
    s=right
    while s[1] is not None: s=s[1]
    return (s[0],left,delete(right,s[0]))
t=(5,(2,None,None),(8,(6,None,None),(9,None,None)))
print(delete(t,5))
