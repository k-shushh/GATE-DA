# Write a linear-time inorder traversal using an output list and append.

t=('A',('B',None,None),('C',('D',None,None),None)); out=[]
def visit(t):
    if t:
        visit(t[1]); out.append(t[0]); visit(t[2])
visit(t)
assert out==['B','A','D','C']
