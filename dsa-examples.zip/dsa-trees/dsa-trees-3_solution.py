# Delete a root with only one child and verify the child becomes the root.

def remove_root(t):
    k,left,right=t
    if left is None: return right
    if right is None: return left
    raise ValueError('two-child case needs successor')
assert remove_root((5,(2,None,None),None))==(2,None,None)
