# 02 · Reconstructing trees and binary search insertion

class Node:
    def __init__(self,k): self.key,self.left,self.right=k,None,None
def insert(t,k):
    if t is None: return Node(k)
    if k<t.key: t.left=insert(t.left,k)
    elif k>t.key: t.right=insert(t.right,k)
    return t
def inorder(t,out):
    if t: inorder(t.left,out); out.append(t.key); inorder(t.right,out)
root=None
for k in [5,2,8,1,3]: root=insert(root,k)
out=[]; inorder(root,out)
print(out)
