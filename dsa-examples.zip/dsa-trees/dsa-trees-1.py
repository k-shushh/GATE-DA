# 01 · Tree terminology and traversal orders

tree=('A',('B',None,None),('C',('D',None,None),None))
def walk(t,order):
    if t is None: return []
    x,left,right=t
    if order=='pre': return [x]+walk(left,order)+walk(right,order)
    if order=='in': return walk(left,order)+[x]+walk(right,order)
    return walk(left,order)+walk(right,order)+[x]
for order in ['pre','in','post']: print(''.join(walk(tree,order)))
