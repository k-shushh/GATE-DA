# 01 · Symmetric, skew-symmetric and triangular matrices
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,5.],[1.,4.]])
print((A+A.T)/2);print((A-A.T)/2)
