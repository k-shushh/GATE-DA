# 02 · Gaussian elimination, echelon form and pivoting
import numpy as np
np.set_printoptions(precision=4, suppress=True)
M=np.array([[1.,2.,5.],[3.,4.,11.]])
M[1]-=3*M[0]
print(M)
y=M[1,2]/M[1,1];x=M[0,2]-M[0,1]*y
print(x,y)
