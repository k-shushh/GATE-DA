# 03 · Basis, dimension and change of coordinates
import numpy as np
np.set_printoptions(precision=4, suppress=True)
B=np.array([[1.,1.],[1.,-1.]])
print(np.linalg.solve(B,np.array([4.,2.])))
