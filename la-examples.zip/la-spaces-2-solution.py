# 02 · Dependence, independence and redundancy
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1,2],[2,4]])
print(A@np.array([2,-1]))
