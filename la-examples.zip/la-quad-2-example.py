# 02 · Principal axes and the Rayleigh quotient
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,2.]])
w,Q=np.linalg.eigh(A)
print(w)
print(Q.T@A@Q)
