# 01 · Project a vector onto a line or subspace
import numpy as np
np.set_printoptions(precision=4, suppress=True)
a=np.array([1.,1.]);b=np.array([2.,0.])
p=a*(a@b)/(a@a);r=b-p
print(p,r@r)
