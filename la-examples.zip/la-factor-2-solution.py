# 02 · Permutation matrices and partial pivoting
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[0.,1.],[2.,3.]])
print(np.linalg.solve(A,[2.,8.]))
