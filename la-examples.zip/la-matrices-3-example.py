# 03 · Partitioned matrices and Schur complements
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.]]);B=np.array([[1.]]);C=B.T;D=np.array([[3.]])
S=D-C@np.linalg.solve(A,B)
print(S)
print(round(np.linalg.det(A)*np.linalg.det(S),4))
