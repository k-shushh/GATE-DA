# 01 · Project a vector onto a line or subspace
import numpy as np
np.set_printoptions(precision=4, suppress=True)
a=np.array([1.,2.]);b=np.array([3.,1.])
p=a*(a@b)/(a@a);r=b-p
print(p,r,a@r)
