# 01 · Vector spaces and the subspace test
import numpy as np
np.set_printoptions(precision=4, suppress=True)
B=np.array([[-2,1],[1,0],[0,1]])
x=B@np.array([3,4])
print(x)
print(np.array([1,2,-1])@x)
