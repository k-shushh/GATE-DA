# 01 · Singular value decomposition from first principles
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[3.,0.],[0.,2.],[0.,0.]])
U,s,Vt=np.linalg.svd(A,full_matrices=False)
print(s, U.shape, Vt.shape)
print(np.allclose(U@np.diag(s)@Vt,A))
