# 02 · Gram–Schmidt and QR factorization
import numpy as np
np.set_printoptions(precision=4, suppress=True)
a=np.array([1.,0.,1.]);b=np.array([1.,1.,0.])
v=b-a*(a@b)/(a@a)
print(v,a@v)
