# 01 · Symmetric, skew-symmetric and triangular matrices
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,4.],[2.,3.]])
S=(A+A.T)/2;K=(A-A.T)/2;x=np.array([2.,1.])
print(S);print(K);print(x@A@x,x@S@x)
