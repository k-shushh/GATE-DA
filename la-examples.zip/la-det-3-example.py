# 03 · Determinant parameters and structural shortcuts
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([1.,2.]);v=np.array([3.,4.])
A=np.eye(2)+np.outer(u,v)
print(A);print(round(np.linalg.det(A),4),1+v@u)
