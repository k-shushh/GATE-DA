# 03 · Truncated SVD and the bridge to PCA
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.diag([5.,3.,1.])
U,s,Vt=np.linalg.svd(A)
Ak=(U[:,:2]*s[:2])@Vt[:2]
print(Ak)
print(np.linalg.norm(A-Ak,'fro'))
