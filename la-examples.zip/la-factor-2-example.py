# 02 · Permutation matrices and partial pivoting
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[0.,2.],[1.,3.]])
P=np.array([[0.,1.],[1.,0.]])
print(P@A)
print(np.linalg.solve(P@A,P@np.array([4.,7.])))
