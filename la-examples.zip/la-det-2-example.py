# 02 · Efficient determinant computation
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.,0.],[2.,5.,1.],[0.,1.,3.]])
print(round(np.linalg.det(A),4))
