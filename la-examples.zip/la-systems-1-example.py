# 01 · Translate equations into Ax=b
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,1.],[1.,-1.]])
b=np.array([3.,1.]);x=np.linalg.solve(A,b)
print(x);print(A@x)
