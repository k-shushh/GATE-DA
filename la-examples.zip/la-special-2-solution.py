# 02 · Orthogonal matrices preserve geometry
import numpy as np
np.set_printoptions(precision=4, suppress=True)
Q=np.diag([1.,-1.]);x=np.array([2.,3.])
print(Q.T@Q);print(Q@x)
