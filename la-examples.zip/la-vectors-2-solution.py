# 02 · Dot products, norms and angles
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([-2.,1.,2.])
print(np.linalg.norm(u))
print(u/np.linalg.norm(u))
