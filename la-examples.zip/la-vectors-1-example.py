# 01 · Scalars, vectors and linear combinations
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([1,2]);v=np.array([2,-1])
print(3*u+2*v)
