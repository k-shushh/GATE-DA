# 03 · Truncated SVD and the bridge to PCA
import numpy as np
np.set_printoptions(precision=4, suppress=True)
s=np.array([4.,2.,1.])
print(s[1],np.sum(s[1:]**2))
