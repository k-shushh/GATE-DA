# 03 · Least squares from geometry to regression
import numpy as np
np.set_printoptions(precision=4, suppress=True)
t=np.array([0.,1.,2.]);A=np.column_stack([np.ones(3),t]);y=np.array([1.,2.,2.])
beta=np.linalg.lstsq(A,y,rcond=None)[0]
print(beta);print(A@beta)
