# 03 · Partitioned matrices and Schur complements
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[4.]]);B=np.array([[2.]]);D=np.array([[3.]])
S=D-B.T@np.linalg.solve(A,B)
print(round(float(np.linalg.det(A)*np.linalg.det(S)),4))
