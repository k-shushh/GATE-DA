# 03 · Least squares from geometry to regression
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.ones((3,1));b=np.array([1.,2.,6.])
x=np.linalg.lstsq(A,b,rcond=None)[0]
print(x);print(b-A@x);print(A.T@(b-A@x))
