# 01 · Elimination becomes LU decomposition
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[4.,3.]])
L=np.array([[1.,0.],[2.,1.]])
U=np.array([[2.,1.],[0.,1.]])
print(L@U)
print(np.linalg.solve(U,np.linalg.solve(L,[3.,7.])))
