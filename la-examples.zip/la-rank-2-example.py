# 02 · Rank inequalities and invertible transformations
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.,3.],[2.,4.,6.]])
print(np.linalg.matrix_rank(A),np.linalg.matrix_rank(A.T@A))
