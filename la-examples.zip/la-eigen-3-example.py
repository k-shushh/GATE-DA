# 03 · Powers, similarity and eigenvalue shortcuts
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,2.]])
print(np.allclose(A@A,4*A-3*np.eye(2)))
print(np.linalg.matrix_power(A,3))
