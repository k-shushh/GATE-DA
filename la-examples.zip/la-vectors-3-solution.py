# 03 · Linear transformations and the column picture
import numpy as np
np.set_printoptions(precision=4, suppress=True)
R=np.array([[0,-1],[1,0]])
print(R@np.array([2,1]))
