# 02 · Pseudoinverse and minimum-norm least squares
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,1.]])
print(np.linalg.pinv(A)@np.array([2.]))
