# 01 · Reading and classifying a quadratic form
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.],[2.,1.]])
print(np.linalg.eigvalsh(A))
for x in [np.array([1,1]),np.array([1,-1])]: print(x@A@x)
