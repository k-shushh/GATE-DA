# 02 · Dot products, norms and angles
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([3.,4.]);v=np.array([4.,-3.])
print('dot',u@v)
print('unit',u/np.linalg.norm(u))
