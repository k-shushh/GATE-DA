# 01 · Reading and classifying a quadratic form
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,2.]])
print(np.linalg.eigvalsh(A))
