# 02 · Transpose, inverse and useful identities
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.],[3.,4.]])
B=np.linalg.inv(A)
print(B);print(np.allclose(A@B,np.eye(2)))
