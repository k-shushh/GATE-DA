# 02 · Rank inequalities and invertible transformations
rA,rB,n=2,2,3
print(max(0,rA+rB-n),min(rA,rB))
