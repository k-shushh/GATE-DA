# 03 · Cholesky, conditioning and residuals
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[4.,2.],[2.,3.]])
L=np.linalg.cholesky(A)
print(L)
print(np.allclose(L@L.T,A))
