# 03 · Free variables and parameter-dependent systems
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.,1.],[0.,1.,-1.]])
p=np.array([1.,1.,0.]);v=np.array([-3.,1.,1.])
print(A@p);print(A@v)
