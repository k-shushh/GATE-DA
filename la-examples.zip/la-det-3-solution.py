# 03 · Determinant parameters and structural shortcuts
import numpy as np
np.set_printoptions(precision=4, suppress=True)
for a in [-2.,0.,2.,3.]:
    A=np.array([[a,2.],[2.,a]])
    print(a,round(np.linalg.det(A),4))
