# 02 · Dependence, independence and redundancy
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1,0,1],[0,1,1]])
print(A@np.array([1,1,-1]))
print('rank',np.linalg.matrix_rank(A))
