# 02 · Transpose, inverse and useful identities
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,1.]])
print(np.linalg.inv(A))
print(np.linalg.solve(A,np.array([3.,2.])))
