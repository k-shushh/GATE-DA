# 02 · Gram–Schmidt and QR factorization
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,1.],[1.,0.]])
Q,R=np.linalg.qr(A)
print(np.allclose(Q.T@Q,np.eye(2)))
print(np.allclose(Q@R,A))
