# 01 · Find eigenvalues and eigenspaces
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[4.,1.],[0.,2.]])
for lam,v in [(4.,np.array([1.,0.])),(2.,np.array([1.,-2.]))]:print(np.allclose(A@v,lam*v))
