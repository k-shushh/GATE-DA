# 01 · Find eigenvalues and eigenspaces
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[1.,2.]])
w,V=np.linalg.eigh(A)
print(w)
print(np.allclose(A@V,V@np.diag(w)))
