# 03 · Powers, similarity and eigenvalue shortcuts
eigenvalues=[2.,-1.]
print([x*x+3 for x in eigenvalues])
print([1/x for x in eigenvalues])
