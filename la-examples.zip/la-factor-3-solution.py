# 03 · Cholesky, conditioning and residuals
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[9.,3.],[3.,5.]])
print(np.linalg.cholesky(A))
