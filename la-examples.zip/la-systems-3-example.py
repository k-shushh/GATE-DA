# 03 · Free variables and parameter-dependent systems
import numpy as np
np.set_printoptions(precision=4, suppress=True)
for a in [1.,2.,3.]:
    A=np.array([[1.,1.],[1.,a]]);b=np.array([2.,3.])
    print(a,np.linalg.matrix_rank(A),np.linalg.matrix_rank(np.column_stack([A,b])))
