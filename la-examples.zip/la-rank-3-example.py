# 03 · Orthogonal complements and solvability certificates
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,1.],[2.,2.]]);y=np.array([-2.,1.])
print(A.T@y)
for b in [np.array([1.,2.]),np.array([1.,3.])]:print(y@b)
