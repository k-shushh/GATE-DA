# 02 · Multiplicity and diagonalization
import numpy as np
np.set_printoptions(precision=4, suppress=True)
J=np.array([[1.,1.],[0.,1.]])
print('eigenspace dimension',2-np.linalg.matrix_rank(J-np.eye(2)))
print('identity eigenspace dimension',2-np.linalg.matrix_rank(np.eye(2)-np.eye(2)))
