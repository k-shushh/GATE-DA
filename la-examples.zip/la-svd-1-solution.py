# 01 · Singular value decomposition from first principles
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[0.,2.],[0.,0.]])
print(np.linalg.svd(A,compute_uv=False))
print(np.linalg.matrix_rank(A))
