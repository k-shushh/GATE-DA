# 01 · Rank–nullity and the four fundamental spaces
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,2.,3.],[2.,4.,6.]])
r=np.linalg.matrix_rank(A)
print('rank',r,'nullity',A.shape[1]-r,'left nullity',A.shape[0]-r)
