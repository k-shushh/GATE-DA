# 01 · Rank–nullity and the four fundamental spaces
m,n,r=4,7,3
print(n-r,m-r)
