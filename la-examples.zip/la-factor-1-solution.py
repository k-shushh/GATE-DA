# 01 · Elimination becomes LU decomposition
import numpy as np
np.set_printoptions(precision=4, suppress=True)
L=np.array([[1.,0.],[2.,1.]])
U=np.array([[3.,2.],[0.,1.]])
print(L@U)
