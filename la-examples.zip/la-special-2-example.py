# 02 · Orthogonal matrices preserve geometry
import numpy as np
np.set_printoptions(precision=4, suppress=True)
Q=np.array([[0.,-1.],[1.,0.]])
x=np.array([3.,4.])
print(Q.T@Q);print(Q@x);print(np.linalg.norm(Q@x))
