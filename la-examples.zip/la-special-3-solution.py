# 03 · Idempotent matrices and projection matrices
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([1.,2.]);P=np.outer(u,u)/(u@u)
print(P);print(P@np.array([3.,0.]))
