# 02 · Principal axes and the Rayleigh quotient
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.diag([2.,7.])
print(9*np.linalg.eigvalsh(A))
