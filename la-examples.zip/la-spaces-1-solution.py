# 01 · Vector spaces and the subspace test
import numpy as np
np.set_printoptions(precision=4, suppress=True)
v=np.array([1,0])
print('v allowed',bool(v[0]>=0))
print('-v allowed',bool((-v)[0]>=0))
