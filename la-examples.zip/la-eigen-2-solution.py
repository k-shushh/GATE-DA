# 02 · Multiplicity and diagonalization
import numpy as np
np.set_printoptions(precision=4, suppress=True)
J=np.array([[2.,1.],[0.,2.]])
print(3-np.linalg.matrix_rank(np.eye(3)-np.eye(3)))
print(2-np.linalg.matrix_rank(J-2*np.eye(2)))
