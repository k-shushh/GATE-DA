# 03 · Linear transformations and the column picture
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1,1],[0,1]])
print(A@np.array([2,3]))
