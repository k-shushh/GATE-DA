# 01 · Determinants as signed volume scaling
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[2.,1.],[0.,3.]])
print(round(np.linalg.det(A),4))
