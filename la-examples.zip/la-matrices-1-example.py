# 01 · Matrix arithmetic without shape mistakes
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1,2],[0,1]]);B=np.array([[2,0],[1,3]])
print(A@B)
print(B@A)
