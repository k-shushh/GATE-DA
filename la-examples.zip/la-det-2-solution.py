# 02 · Efficient determinant computation
n=3;detA=5
print(2**n*detA)
