# 02 · Gaussian elimination, echelon form and pivoting
import numpy as np
np.set_printoptions(precision=4, suppress=True)
M=np.array([[0.,2.,4.],[1.,1.,3.]])
M[[0,1]]=M[[1,0]]
y=M[1,2]/M[1,1];x=M[0,2]-M[0,1]*y
print(M);print(x,y)
