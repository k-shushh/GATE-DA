# 03 · Quadratic minimization and least-squares curvature
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.diag([2.,4.]);b=np.array([2.,4.])
x=np.linalg.solve(A,b)
print(x, .5*x@A@x-b@x)
