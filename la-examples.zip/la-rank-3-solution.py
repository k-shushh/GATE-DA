# 03 · Orthogonal complements and solvability certificates
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.ones((3,1))
for b in [np.array([2.,2.,2.]),np.array([2.,2.,3.])]:
    print(np.linalg.matrix_rank(A)==np.linalg.matrix_rank(np.column_stack([A,b])))
