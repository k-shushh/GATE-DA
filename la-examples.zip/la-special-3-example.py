# 03 · Idempotent matrices and projection matrices
import numpy as np
np.set_printoptions(precision=4, suppress=True)
u=np.array([1.,1.]);P=np.outer(u,u)/(u@u)
print(P);print(P@np.array([3.,1.]));print(np.allclose(P@P,P))
