# 01 · Translate equations into Ax=b
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=np.array([[1.,1.],[2.,2.]])
for b in [np.array([2.,4.]),np.array([2.,5.])]:
    print(np.linalg.matrix_rank(A),np.linalg.matrix_rank(np.column_stack([A,b])))
