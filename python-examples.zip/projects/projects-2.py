# 02 · Project: a text-frequency report
# Add an optional stop-word set and verify that uppercase stop words are handled under a documented policy.

import re
from collections import Counter
def top_words(text, k=3):
    if k < 0:
        raise ValueError('negative k')
    tokens = re.findall(r'[a-z]+', text.casefold())
    counts = Counter(tokens)
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]
print(top_words('Learn Python. Learn by doing. Python helps!', 3))
