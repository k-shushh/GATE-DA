# 03 · Project: your exam tracing workflow
# Write your own short program containing one alias, one copy, and one rebinding. Predict every output and explain the arrows.

def update(items):
    alias = items
    copy = items[:]
    alias.append(3)
    copy.append(4)
    return copy
a = [1, 2]
b = update(a)
print(a, b, a is b)
