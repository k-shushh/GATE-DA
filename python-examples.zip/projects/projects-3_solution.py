# Hands-on solution: Write your own short program containing one alias, one copy, and one rebinding. Predict every output and explain the arrows.

a = [1]
b = a
c = a[:]
b.append(2)
b = [9]
print(a, b, c)
assert a == [1,2] and b == [9] and c == [1]
