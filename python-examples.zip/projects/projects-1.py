# 01 · Project: a study-session analyser
# Add tests for an empty list, an empty topic, a Boolean duration, and repeated normalised topics.

def analyse(rows):
    totals, rejected = {}, []
    for i, row in enumerate(rows):
        topic, minutes = row.get('topic'), row.get('minutes')
        if not isinstance(topic, str) or not topic.strip() or type(minutes) is not int or minutes < 0:
            rejected.append(i)
            continue
        topic = ' '.join(topic.casefold().split())
        totals[topic] = totals.get(topic, 0) + minutes
    return totals, rejected
rows = [{'topic':' Python ', 'minutes':25}, {'topic':'python', 'minutes':35}, {'topic':'loops','minutes':-1}]
print(analyse(rows))
