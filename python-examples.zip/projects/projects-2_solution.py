# Hands-on solution: Add an optional stop-word set and verify that uppercase stop words are handled under a documented policy.

import re
from collections import Counter
def top_words(text, stop=()):
    stop = {word.casefold() for word in stop}
    counts = Counter(w for w in re.findall(r'[a-z]+', text.casefold()) if w not in stop)
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))
print(top_words('The data and the model', {'THE', 'and'}))
