# Hands-on solution: Add tests for an empty list, an empty topic, a Boolean duration, and repeated normalised topics.

def analyse(rows):
    totals, rejected = {}, []
    for i, row in enumerate(rows):
        t, n = row.get('topic'), row.get('minutes')
        if not isinstance(t,str) or not t.strip() or type(n) is not int or n < 0:
            rejected.append(i); continue
        t = ' '.join(t.casefold().split())
        totals[t] = totals.get(t,0)+n
    return totals,rejected
assert analyse([]) == ({},[])
assert analyse([{'topic':'','minutes':1},{'topic':'x','minutes':True}]) == ({},[0,1])
assert analyse([{'topic':' X ','minutes':2},{'topic':'x','minutes':3}]) == ({'x':5},[])
print('passed')
