# 03 · Graphs, visited state and BFS
# Add an isolated vertex E and verify it is absent from bfs(graph,"A").

from collections import deque
graph = {'A': ['B', 'C'], 'B': ['A', 'D'], 'C': ['A', 'D'], 'D': ['B', 'C']}
def bfs(graph, start):
    distance, queue = {start: 0}, deque([start])
    while queue:
        u = queue.popleft()
        for v in graph[u]:
            if v not in distance:
                distance[v] = distance[u] + 1
                queue.append(v)
    return distance
print(bfs(graph, 'A'))
