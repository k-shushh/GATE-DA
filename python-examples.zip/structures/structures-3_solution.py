# Hands-on solution: Add an isolated vertex E and verify it is absent from bfs(graph,"A").

from collections import deque
graph = {'A':['B'], 'B':['A'], 'E':[]}
seen, queue = {'A'}, deque(['A'])
while queue:
    for v in graph[queue.popleft()]:
        if v not in seen:
            seen.add(v); queue.append(v)
print(sorted(seen))
