# 02 · Linked nodes and binary trees
# Rewrite inorder as a generator using yield from.

class Node:
    def __init__(self, value, left=None, right=None):
        self.value, self.left, self.right = value, left, right
def inorder(node):
    if node is None:
        return []
    return inorder(node.left) + [node.value] + inorder(node.right)
root = Node(4, Node(2, Node(1), Node(3)), Node(6))
print(inorder(root))
import heapq
heap = [7, 2, 5, 1]
heapq.heapify(heap)
print([heapq.heappop(heap) for _ in range(4)])
