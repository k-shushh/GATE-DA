# Hands-on solution: Use a deque to simulate serving three named tasks in arrival order.

from collections import deque
tasks = deque(["read", "solve", "review"])
while tasks:
    print(tasks.popleft())
