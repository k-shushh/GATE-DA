# Hands-on solution: Rewrite inorder as a generator using yield from.

class Node:
    def __init__(self, value, left=None, right=None):
        self.value, self.left, self.right = value, left, right
def inorder(node):
    if node is not None:
        yield from inorder(node.left)
        yield node.value
        yield from inorder(node.right)
print(list(inorder(Node(2, Node(1), Node(3)))))
