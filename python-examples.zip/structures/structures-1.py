# 01 · Stack and queue behaviour
# Use a deque to simulate serving three named tasks in arrival order.

from collections import deque
stack = []
stack.append("A"); stack.append("B")
print(stack.pop())
queue = deque(["A", "B"])
print(queue.popleft())
def balanced(text):
    stack, pairs = [], {')': '(', ']': '[', '}': '{'}
    for c in text:
        if c in "([{": stack.append(c)
        elif c in pairs:
            if not stack or stack.pop() != pairs[c]: return False
    return not stack
print(balanced("([{}])"), balanced("([)]"))
