# 02 · Arguments and the mutable-default trap
# Implement total(*values, offset=0) and call it with an unpacked list.

def collect_bad(x, bucket=[]):
    bucket.append(x)
    return bucket
print(collect_bad(1))
print(collect_bad(2))
def collect(x, bucket=None):
    if bucket is None:
        bucket = []
    bucket.append(x)
    return bucket
print(collect(1), collect(2))
def scale(x, *, factor=2):
    return x * factor
print(scale(3, factor=4))
