# Hands-on solution: Implement total(*values, offset=0) and call it with an unpacked list.

def total(*values, offset=0):
    return sum(values) + offset
print(total(*[2, 3, 4], offset=1))
