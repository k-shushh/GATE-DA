# Hands-on solution: Compare fib_loop with fib for every n from 0 through 20.

from functools import cache
@cache
def fib(n):
    return n if n < 2 else fib(n-1) + fib(n-2)
def fib_loop(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
assert all(fib(n) == fib_loop(n) for n in range(21))
print("all matched")
