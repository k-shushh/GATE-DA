# 04 · Recursion: descent, base case, unwind
# Write recursive sum_digits(n) for nonnegative integers, using // and %.

def factorial(n):
    if n < 0:
        raise ValueError("n must be nonnegative")
    if n == 0:
        return 1
    return n * factorial(n - 1)
print(factorial(4))
def trace(n):
    if n == 0:
        return
    print("enter", n)
    trace(n - 1)
    print("leave", n)
trace(3)
