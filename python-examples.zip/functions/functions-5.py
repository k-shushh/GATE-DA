# 05 · Repeated work and memoisation
# Compare fib_loop with fib for every n from 0 through 20.

from functools import cache
@cache
def fib(n):
    if n < 2:
        return n
    return fib(n - 1) + fib(n - 2)
print(fib(10))
def fib_loop(n):
    a, b = 0, 1
    for _ in range(n):
        a, b = b, a + b
    return a
def gcd(a, b):
    return abs(a) if b == 0 else gcd(b, a % b)
print(fib_loop(10), gcd(48, 18))
