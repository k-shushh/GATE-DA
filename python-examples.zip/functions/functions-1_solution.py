# Hands-on solution: Write safe_mean(values), returning None for an empty sequence.

def safe_mean(values):
    return sum(values) / len(values) if values else None
print(safe_mean([]), safe_mean([2, 4]))
