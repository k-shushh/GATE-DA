# 01 · Parameters, return and contracts
# Write safe_mean(values), returning None for an empty sequence.

def summary(values):
    if not values:
        raise ValueError("at least one value required")
    return min(values), max(values), sum(values) / len(values)
low, high, mean = summary([2, 4, 9])
print(low, high, mean)
def touch(items):
    items.append(3)
    items = [99]
a = [1, 2]
print(touch(a))
print(a)
