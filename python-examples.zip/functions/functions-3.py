# 03 · Scope, closures and name lookup
# Create make_multiplier(k) returning a function that multiplies its input by k.

x = 10
def outer():
    count = 0
    def step():
        nonlocal count
        count += 1
        return count
    return step
counter = outer()
print(counter(), counter(), x)
late = [lambda: i for i in range(3)]
early = [lambda i=i: i for i in range(3)]
print([f() for f in late])
print([f() for f in early])
