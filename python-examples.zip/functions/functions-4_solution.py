# Hands-on solution: Write recursive sum_digits(n) for nonnegative integers, using // and %.

def sum_digits(n):
    if n < 10:
        return n
    return n % 10 + sum_digits(n // 10)
print(sum_digits(4072))
