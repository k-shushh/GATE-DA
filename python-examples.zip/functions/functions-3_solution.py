# Hands-on solution: Create make_multiplier(k) returning a function that multiplies its input by k.

def make_multiplier(k):
    def multiply(x):
        return k * x
    return multiply
triple = make_multiplier(3)
print(triple(7))
