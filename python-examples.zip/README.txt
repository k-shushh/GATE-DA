GATE Lab practice pack
Run any example with Python 3: python filename.py
Each file is independent. Files used by examples are created in the working directory.
Examples with a _solution suffix solve the corresponding hands-on task.
