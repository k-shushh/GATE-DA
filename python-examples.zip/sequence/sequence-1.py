# 01 · Sequence operations and list methods
# Remove duplicates from [3,1,3,2,1] while preserving the first occurrence order.

a = [1, 2]
a.append([3, 4])
print(a)
b = [1, 2]
b.extend([3, 4])
print(b)
removed = b.pop(1)
result = b.reverse()
print(removed, b, result)
print((5,), type((5)).__name__)
