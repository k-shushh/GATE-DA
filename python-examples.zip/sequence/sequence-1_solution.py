# Hands-on solution: Remove duplicates from [3,1,3,2,1] while preserving the first occurrence order.

values = [3, 1, 3, 2, 1]
result = []
for x in values:
    if x not in result:
        result.append(x)
print(result)
