# Hands-on solution: Create aliases x and y for [1], execute x += [2], then x = x + [3]. Predict y after each line.

x = [1]
y = x
x += [2]
print(y)
x = x + [3]
print(x, y)
