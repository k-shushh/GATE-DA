# 03 · Matrices and nested-container traps
# Create a 3×3 identity matrix with independent rows.

bad = [[0] * 3] * 2
good = [[0] * 3 for _ in range(2)]
bad[0][1] = 5
good[0][1] = 5
print(bad)
print(good)
t = ([1], 2)
t[0].append(3)
print(t)
print(list(zip(*[[1, 2], [3, 4]])))
