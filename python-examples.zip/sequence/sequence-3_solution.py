# Hands-on solution: Create a 3×3 identity matrix with independent rows.

n = 3
identity = [[int(r == c) for c in range(n)] for r in range(n)]
print(identity)
