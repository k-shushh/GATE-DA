# 02 · Aliasing, shallow and deep copies
# Create aliases x and y for [1], execute x += [2], then x = x + [3]. Predict y after each line.

from copy import deepcopy
a = [[1], [2]]
b = a[:]
c = deepcopy(a)
b[0].append(9)
b[1] = [7]
print(a)
print(b)
print(c)
print(a is b, a[0] is b[0])
