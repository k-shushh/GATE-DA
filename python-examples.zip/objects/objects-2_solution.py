# Hands-on solution: Model a Point(x,y) record and compare two equal coordinate pairs.

from dataclasses import dataclass
@dataclass(frozen=True)
class Point:
    x: float
    y: float
print(Point(2, 3) == Point(2, 3))
