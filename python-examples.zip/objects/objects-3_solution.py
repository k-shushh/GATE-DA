# Hands-on solution: Write a decorator that rejects negative first arguments and preserves the original result.

from functools import wraps
def nonnegative(fn):
    @wraps(fn)
    def wrapped(x):
        if x < 0:
            raise ValueError("negative")
        return fn(x)
    return wrapped
@nonnegative
def double(x):
    return 2*x
print(double(4))
