# 02 · Protocols, composition and inheritance
# Model a Point(x,y) record and compare two equal coordinate pairs.

from dataclasses import dataclass, field
@dataclass
class Playlist:
    name: str
    tracks: list = field(default_factory=list)
    def __len__(self):
        return len(self.tracks)
    def __iter__(self):
        return iter(self.tracks)
p = Playlist("Focus", ["alpha", "beta"])
print(len(p), list(p))
print(Playlist("Empty") == Playlist("Empty"))
