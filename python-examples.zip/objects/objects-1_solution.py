# Hands-on solution: Add an average method that returns zero when no sessions exist.

class StudyLog:
    def __init__(self):
        self.minutes = []
    def average(self):
        return sum(self.minutes) / len(self.minutes) if self.minutes else 0
log = StudyLog()
print(log.average())
log.minutes.extend([20, 40])
print(log.average())
