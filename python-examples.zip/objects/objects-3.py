# 03 · Decorators, context and advanced boundaries
# Write a decorator that rejects negative first arguments and preserves the original result.

from functools import wraps
def announce(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        print("calling", fn.__name__)
        return fn(*args, **kwargs)
    return wrapper
@announce
def square(x):
    return x * x
print(square(5))
