# 01 · Classes and independent state
# Add an average method that returns zero when no sessions exist.

class StudyLog:
    def __init__(self, name):
        self.name = name
        self.minutes = []
    def add(self, minutes):
        if minutes < 0:
            raise ValueError("negative duration")
        self.minutes.append(minutes)
    def total(self):
        return sum(self.minutes)
a, b = StudyLog("Asha"), StudyLog("Dev")
a.add(25)
a.add(30)
print(a.total(), b.total())
