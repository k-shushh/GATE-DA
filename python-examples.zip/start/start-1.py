# 01 · From a file to a running program
# Change the quantity to 5 and discount to 20%. Predict the total before running.

price = 120
quantity = 3
subtotal = price * quantity
discount = 0.10
total = subtotal * (1 - discount)
print(f"Total: {total:.2f}")
