# 02 · Names, objects and types
# Start with x=2,y=5. Swap them without a temporary name, then print their types.

a = 7
b = a
a = a + 1
print(a, b)
a, b = b, a
print(a, b)
print(type(3).__name__, int(-2.9), None is None)
