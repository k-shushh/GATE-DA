# 04 · Comparisons, truth and bits
# Write a safe test for a nonempty list whose first element is positive.

print(bool("False"), bool([]))
print(0 or 7, 3 and 8)
print(0 < 4 < 5)
print(6 & 3, 6 | 3, 6 ^ 3, 1 << 3)
print(~5, -3 >> 1)
