# 03 · Arithmetic and the negative-number trap
# For a=7,b=-3, calculate quotient and remainder by hand, then check the identity.

import math
print(-7 // 3, -7 % 3)
print((-7 // 3) * 3 + (-7 % 3))
print(-2 ** 2, (-2) ** 2, 2 ** 3 ** 2)
print(0.1 + 0.2 == 0.3, math.isclose(0.1 + 0.2, 0.3))
