# Hands-on solution: For a=7,b=-3, calculate quotient and remainder by hand, then check the identity.

a, b = 7, -3
print(a // b, a % b)
assert a == (a // b) * b + a % b
