# Hands-on solution: Change the quantity to 5 and discount to 20%. Predict the total before running.

price, quantity, discount = 120, 5, 0.20
print(f"Total: {price * quantity * (1-discount):.2f}")
