# Hands-on solution: Write a safe test for a nonempty list whose first element is positive.

values = []
print(bool(values) and values[0] > 0)
