# Hands-on solution: Start with x=2,y=5. Swap them without a temporary name, then print their types.

x, y = 2, 5
x, y = y, x
print(x, y, type(x).__name__, type(y).__name__)
