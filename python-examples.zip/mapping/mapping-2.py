# 02 · Sets and choosing the right container
# Find IDs present in yesterday=[1,2,3] but absent today=[2,4].

a, b = {1, 2, 3}, {3, 4}
print(sorted(a | b))
print(sorted(a & b))
print(sorted(a - b))
print(sorted(a ^ b))
print(list(dict.fromkeys([3, 1, 3, 2, 1])))
