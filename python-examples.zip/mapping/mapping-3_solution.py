# Hands-on solution: Group ["ant","apple","bat","bee"] by first letter.

groups = {}
for word in ["ant", "apple", "bat", "bee"]:
    groups.setdefault(word[0], []).append(word)
print(groups)
