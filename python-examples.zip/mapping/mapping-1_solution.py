# Hands-on solution: Build a histogram for [2,2,3,1,3,3] without Counter.

counts = {}
for value in [2, 2, 3, 1, 3, 3]:
    counts[value] = counts.get(value, 0) + 1
print(counts)
