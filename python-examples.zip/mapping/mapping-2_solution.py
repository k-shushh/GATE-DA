# Hands-on solution: Find IDs present in yesterday=[1,2,3] but absent today=[2,4].

yesterday, today = {1, 2, 3}, {2, 4}
print(sorted(yesterday - today))
