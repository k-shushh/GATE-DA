# 03 · Counting and grouping patterns
# Group ["ant","apple","bat","bee"] by first letter.

from collections import Counter, defaultdict
print(Counter("banana")["a"])
groups = defaultdict(list)
for name, team in [("Asha", "red"), ("Dev", "blue"), ("Ira", "red")]:
    groups[team].append(name)
print(dict(groups))
def two_sum(values, target):
    seen = {}
    for i, x in enumerate(values):
        if target - x in seen:
            return seen[target - x], i
        seen[x] = i
    return None
print(two_sum([3, 3, 8], 6))
