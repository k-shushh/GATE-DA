# 01 · Dictionaries and hashable keys
# Build a histogram for [2,2,3,1,3,3] without Counter.

counts = {}
for word in ["data", "python", "data"]:
    counts[word] = counts.get(word, 0) + 1
print(counts)
print("python" in counts, 2 in counts)
d = {True: "first", 1: "second", 1.0: "third"}
print(len(d), d[True])
