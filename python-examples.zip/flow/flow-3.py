# 03 · break, continue, else and nested loops
# Return the first negative number in a list, or None if no negative exists.

n = 17
for divisor in range(2, int(n ** 0.5) + 1):
    if n % divisor == 0:
        print("composite")
        break
else:
    print("prime" if n >= 2 else "not prime")
count = 0
for i in range(4):
    for j in range(i):
        count += 1
print(count)
