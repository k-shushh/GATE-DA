# Hands-on solution: Classify a year as leap if divisible by 400, or divisible by 4 but not 100. Test 1900, 2000, 2024.

for year in [1900, 2000, 2024]:
    leap = year % 400 == 0 or (year % 4 == 0 and year % 100 != 0)
    print(year, leap)
