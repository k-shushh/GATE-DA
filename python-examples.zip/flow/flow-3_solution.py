# Hands-on solution: Return the first negative number in a list, or None if no negative exists.

def first_negative(values):
    for value in values:
        if value < 0:
            return value
    return None
print(first_negative([4, 0, -3, -7]))
