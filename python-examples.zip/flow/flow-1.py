# 01 · Decisions and input contracts
# Classify a year as leap if divisible by 400, or divisible by 4 but not 100. Test 1900, 2000, 2024.

score = 78
if not 0 <= score <= 100:
    print("Invalid")
elif score >= 80:
    print("Distinction")
elif score >= 60:
    print("Pass")
else:
    print("Revise")
print("even" if score % 2 == 0 else "odd")
