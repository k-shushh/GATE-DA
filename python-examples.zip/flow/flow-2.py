# 02 · for, range and while
# Compute the sum of odd integers from 1 to 99 with a loop. Then derive it without a loop.

total = 0
for number in range(1, 6):
    total += number
    print(number, total)
n = 13
bits = 0
while n > 0:
    bits += 1
    n //= 2
print("bits:", bits)
