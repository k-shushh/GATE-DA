# Hands-on solution: Compute the sum of odd integers from 1 to 99 with a loop. Then derive it without a loop.

total = 0
for n in range(1, 100, 2):
    total += n
print(total)
print(50 ** 2)
