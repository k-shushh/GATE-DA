# Hands-on solution: Round-trip the string "naïve" through UTF-8 and compare its text length with its byte length.

text = "naïve"
data = text.encode("utf-8")
assert data.decode("utf-8") == text
print(len(text), len(data))
