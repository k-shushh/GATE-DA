# 03 · Text algorithms and edge cases
# Count vowels in text without counting uppercase vowels differently.

def palindrome(text):
    clean = "".join(c.casefold() for c in text if c.isalnum())
    left, right = 0, len(clean) - 1
    while left < right:
        if clean[left] != clean[right]:
            return False
        left += 1
        right -= 1
    return True
print(palindrome("Never odd or even"))
print(palindrome("Python"))
