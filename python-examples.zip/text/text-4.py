# 04 · Unicode, bytes and safe conversion
# Round-trip the string "naïve" through UTF-8 and compare its text length with its byte length.

text = "café"
data = text.encode("utf-8")
print(len(text), len(data))
print(data[0], data.decode("utf-8") == text)
print(ord("A"), chr(66))
mutable = bytearray(b"abc")
mutable[0] = 65
print(bytes(mutable))
