# Hands-on solution: Count vowels in text without counting uppercase vowels differently.

text = "Data Science AND AI"
print(sum(c in "aeiou" for c in text.casefold()))
