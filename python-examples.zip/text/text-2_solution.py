# Hands-on solution: Normalise "  Learn   PYTHON today  " into "learn python today".

text = "  Learn   PYTHON today  "
print(" ".join(text.lower().split()))
