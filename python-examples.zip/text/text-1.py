# 01 · Strings and slicing
# Extract every second character from "abcdefgh" starting at index 1, then reverse the result.

s = "PYTHON"
print(s[0], s[-1])
print(s[1:5:2])
print(s[::-1])
print(s[-1:0:-1])
print(s[99:], s[:99])
