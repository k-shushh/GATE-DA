# 02 · Methods, parsing and formatting
# Normalise "  Learn   PYTHON today  " into "learn python today".

raw = "  Alice, 82, 91, 87  "
parts = raw.strip().split(",")
name = parts[0].strip()
marks = [int(piece) for piece in parts[1:]]
mean = sum(marks) / len(marks)
print(f"{name}: {mean:.2f}")
print("-".join(["DA", "Python", "2027"]))
