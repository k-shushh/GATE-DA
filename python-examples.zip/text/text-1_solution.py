# Hands-on solution: Extract every second character from "abcdefgh" starting at index 1, then reverse the result.

s = "abcdefgh"
print(s[1::2][::-1])
