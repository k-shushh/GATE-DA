# Hands-on solution: Sort ["pear","fig","apple","kiwi"] by length, breaking ties alphabetically.

words = ["pear", "fig", "apple", "kiwi"]
print(sorted(words, key=lambda w: (len(w), w)))
