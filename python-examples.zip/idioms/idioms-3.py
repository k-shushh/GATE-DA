# 03 · Functions as values and stable sorting
# Sort ["pear","fig","apple","kiwi"] by length, breaking ties alphabetically.

rows = [("Ira", 80), ("Dev", 90), ("Asha", 90)]
print(sorted(rows, key=lambda row: (-row[1], row[0])))
print(rows)
print(max(rows, key=lambda row: row[1]))
words = ["aa", "b", "cc", "d"]
print(sorted(words, key=len))
