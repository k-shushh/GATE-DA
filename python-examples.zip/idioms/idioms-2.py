# 02 · Iterators and generators
# Write a generator yielding running totals of [2,5,-1].

def squares(n):
    for i in range(n):
        yield i * i
g = squares(4)
print(next(g))
print(list(g))
print(list(g))
it = iter([10, 20])
print(next(it), next(it), next(it, "done"))
