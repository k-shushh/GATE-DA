# Hands-on solution: Flatten [[1,2],[],[3,4]] and keep only even values.

rows = [[1, 2], [], [3, 4]]
print([x for row in rows for x in row if x % 2 == 0])
