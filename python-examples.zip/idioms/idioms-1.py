# 01 · Comprehensions and iteration helpers
# Flatten [[1,2],[],[3,4]] and keep only even values.

values = [-2, -1, 0, 1, 2]
print([x * x for x in values if x > 0])
print(["+" if x > 0 else "-" for x in values])
print([(i, value) for i, value in enumerate(["a", "b"], start=1)])
print(list(zip([1, 2, 3], ["x", "y"])))
print(any([]), all([]))
