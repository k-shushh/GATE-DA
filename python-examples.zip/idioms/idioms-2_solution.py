# Hands-on solution: Write a generator yielding running totals of [2,5,-1].

def running_total(values):
    total = 0
    for value in values:
        total += value
        yield total
print(list(running_total([2, 5, -1])))
