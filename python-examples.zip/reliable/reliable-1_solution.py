# Hands-on solution: Convert a list of strings into integers, collecting invalid entries separately.

valid, invalid = [], []
for item in ["2", "x", "-4", "3.5"]:
    try:
        valid.append(int(item))
    except ValueError:
        invalid.append(item)
print(valid, invalid)
