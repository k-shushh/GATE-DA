# 02 · Tests and edge cases
# Write tests for a palindrome function, including empty text and mixed case.

def unique_in_order(values):
    return list(dict.fromkeys(values))
cases = [([], []), ([1], [1]), ([2, 1, 2, 3, 1], [2, 1, 3])]
for values, expected in cases:
    before = values[:]
    assert unique_in_order(values) == expected
    assert values == before
print("3 cases passed")
