# 03 · Files, JSON, CSV and context managers
# Round-trip a list of two student records through JSON and verify equality.

import json, csv, io
data = {"topic": "Python", "scores": [8, 9, 10]}
with open("progress.json", "w", encoding="utf-8") as f:
    json.dump(data, f)
with open("progress.json", encoding="utf-8") as f:
    restored = json.load(f)
print(restored["scores"])
text = 'name,score\n"Rao, A",90\nDev,80\n'
rows = list(csv.DictReader(io.StringIO(text)))
print(rows[0]["name"], rows[0]["score"])
