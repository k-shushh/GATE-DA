# Hands-on solution: Extract a reusable clamp(x,low,high) function with validation and three tests.

def clamp(x, low, high):
    if low > high:
        raise ValueError("reversed bounds")
    return min(high, max(low, x))
assert clamp(-1, 0, 10) == 0
assert clamp(5, 0, 10) == 5
assert clamp(12, 0, 10) == 10
print("passed")
