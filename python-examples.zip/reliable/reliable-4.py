# 04 · Modules and a practical workflow
# Extract a reusable clamp(x,low,high) function with validation and three tests.

import math
def distance(x1, y1, x2, y2):
    """Return Euclidean distance between two 2D points."""
    return math.hypot(x2 - x1, y2 - y1)
def main():
    print(distance(0, 0, 3, 4))
if __name__ == "__main__":
    main()
