# Hands-on solution: Write tests for a palindrome function, including empty text and mixed case.

def palindrome(s):
    s = s.casefold()
    return s == s[::-1]
assert palindrome("")
assert palindrome("Aba")
assert not palindrome("ab")
print("passed")
