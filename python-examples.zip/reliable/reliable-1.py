# 01 · Exceptions and debugging deliberately
# Convert a list of strings into integers, collecting invalid entries separately.

def parse_nonnegative(text):
    value = int(text)
    if value < 0:
        raise ValueError("negative value")
    return value
for text in ["12", "oops", "-3"]:
    try:
        value = parse_nonnegative(text)
    except ValueError:
        print("invalid:", text)
    else:
        print("accepted:", value)
