# Hands-on solution: Round-trip a list of two student records through JSON and verify equality.

import json
students = [{"name": "Asha", "mark": 82}, {"name": "Dev", "mark": 90}]
encoded = json.dumps(students)
assert json.loads(encoded) == students
print(encoded)
