# Hands-on solution: Count iterations of repeated integer halving for n=1,2,8,9.

for value in [1, 2, 8, 9]:
    n, count = value, 0
    while n:
        n //= 2
        count += 1
    print(value, count)
