# Hands-on solution: Test lower_bound against bisect_left on empty, singleton and duplicate-containing lists.

from bisect import bisect_left
def lower_bound(a, x):
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo+hi)//2
        if a[mid] < x: lo = mid+1
        else: hi = mid
    return lo
for a in [[], [2], [1, 2, 2, 5]]:
    for x in range(7):
        assert lower_bound(a, x) == bisect_left(a, x)
print("passed")
