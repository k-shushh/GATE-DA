# 02 · Prefix sums and sliding windows
# Implement maximum sum of any two consecutive elements in [-8,-3,-5].

a = [2, -1, 4, 3, -2]
prefix = [0]
for x in a:
    prefix.append(prefix[-1] + x)
print(prefix)
print(prefix[4] - prefix[1])
k = 3
window = best = sum(a[:k])
for right in range(k, len(a)):
    window += a[right] - a[right-k]
    best = max(best, window)
print(best)
