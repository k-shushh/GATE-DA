# 03 · Linear and binary search
# Test lower_bound against bisect_left on empty, singleton and duplicate-containing lists.

def lower_bound(a, target):
    lo, hi = 0, len(a)
    while lo < hi:
        mid = (lo + hi) // 2
        if a[mid] < target:
            lo = mid + 1
        else:
            hi = mid
    return lo
a = [1, 3, 3, 7]
for target in [0, 3, 5, 9]:
    print(target, lower_bound(a, target))
