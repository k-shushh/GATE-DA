# 01 · Time and space from code
# Count iterations of repeated integer halving for n=1,2,8,9.

def operations(n):
    count = 0
    for i in range(n):
        for j in range(i):
            count += 1
    return count
for n in [0, 1, 4, 8]:
    print(n, operations(n), n * (n - 1) // 2)
