# Hands-on solution: Implement maximum sum of any two consecutive elements in [-8,-3,-5].

a, k = [-8, -3, -5], 2
window = best = sum(a[:k])
for right in range(k, len(a)):
    window += a[right] - a[right-k]
    best = max(best, window)
print(best)
